"""This file contains configuration classes for visualization of geometric objects"""

from SimulationToolbox.PhysicalObjects.tool import *
from SimulationToolbox.PhysicalObjects.workpiece import *
from SimulationToolbox.Simulation.process import *
from typing import *
from typing import Mapping, Callable
from SimulationToolbox.Geometry.geometry import *
from SimulationToolbox.Utilities.helpers import *
import enum


class Color:
    r: float
    g: float
    b: float
    alpha: float

    def __init__(self, r, g, b, alpha):
        if r >= 0 and r <= 1 and\
           g >= 0 and g <= 1 and\
           b >= 0 and b <= 1 and\
           alpha >= 0 and alpha <= 1:
            self.r = r
            self.g = g
            self.b = b
            self.alpha = alpha
        else:
            raise Exception('input values not valid')

    @ classmethod
    def red(cls):
        return cls(1, 0, 0, 1)

    @ classmethod
    def green(cls):
        return cls(0, 1, 0, 1)

    @ classmethod
    def blue(cls):
        return cls(0, 0, 1, 1)

    @ classmethod
    def magenta(cls):
        return cls(1, 0, 1, 1)

    @ classmethod
    def black(cls):
        return cls(0, 0, 0, 1)

    @ classmethod
    def white(cls):
        return cls(1, 1, 1, 1)


class Markertype(enum.Enum):
    circle = 1
    square = 2
    x = 3
    dot = 4


class Linestyle(enum.Enum):
    solid = 1
    dotted = 2
    dashed = 3


class PointPlotConfig:
    color: Color
    marker: Markertype
    alpha: float

    def __init__(self, color: Color, marker: Markertype, alpha: float):
        self.color = color
        self.marker = marker
        self.alpha = alpha

    @ classmethod
    def default(cls):
        return cls(Color.black(), Markertype.dot, 1)

    # TODO marktertype dot not supported by plotly
    @ classmethod
    def from_color(cls, color: Color):
        return cls(color, Markertype.dot, 1)


class PointVisualization:
    vector: Vector
    plot_config: PointPlotConfig

    def __init__(self, vector: Vector, plot_config: PointPlotConfig):
        self.vector = copy.deepcopy(vector)
        self.plot_config = copy.deepcopy(plot_config)


class LinePlotConfig:
    color: Color
    width: float
    style: Linestyle
    alpha: float

    def __init__(self, color: Color, width: float, style: Linestyle, alpha: float):
        self.color = color
        self.linewidth = width
        self.style = style
        self.alpha = alpha

    @ classmethod
    def default(cls):
        return cls(Color.black(), 1, Linestyle.solid, 1)

    @ classmethod
    def from_color(cls, color: Color):
        return cls(color, 1, Linestyle.solid, 1)

    @ classmethod
    def hidden(cls):
        return cls(Color(1, 1, 1, 0), 0, Linestyle.solid, 0)


class LineVisualization:
    vector: List[Vector]
    plot_config: LinePlotConfig

    def __init__(self, vectors: List[Vector], plot_config: LinePlotConfig):
        self.vectors = copy.deepcopy(vectors)
        self.plot_config = copy.deepcopy(plot_config)


class PolyPlotConfig:
    boundary: LinePlotConfig
    face_color: Color
    alpha: float

    def __init__(self, face_color: Color, boundary: LinePlotConfig, alpha: float):
        self.boundary = boundary
        self.face_color = face_color
        self.face_color.alpha = alpha
        self.alpha = alpha

    @ classmethod
    def default(cls):
        return cls(Color.blue(), LinePlotConfig.default(), 0.5)

    @ classmethod
    def from_color(cls, face_color: Color, boundary_color: Color):
        return cls(face_color, LinePlotConfig.from_color(boundary_color), 0.5)


class PolygonVisualization:
    vectors: List[Vector]
    plot_config: PolyPlotConfig

    def __init__(self, vectors: List[Vector], plot_config: PolyPlotConfig):
        if len(vectors) > 3:
            Vector.check_coplanarity(vectors)
        self.vectors = copy.deepcopy(vectors)
        self.plot_config = copy.deepcopy(plot_config)


class PosePlotConfig:
    x_config: LinePlotConfig
    y_config: LinePlotConfig
    z_config: LinePlotConfig

    def __init__(self, x_config: LinePlotConfig,
                 y_config: LinePlotConfig,
                 z_config: LinePlotConfig):
        self.x_config = x_config
        self.y_config = y_config
        self.z_config = z_config

    @classmethod
    def default(cls):
        return cls(LinePlotConfig.from_color(Color.red()),
                   LinePlotConfig.from_color(Color.green()),
                   LinePlotConfig.from_color(Color.blue()))

    @classmethod
    def unicolor(cls, color: Color):
        return cls(LinePlotConfig.from_color(color),
                   LinePlotConfig.from_color(color),
                   LinePlotConfig.from_color(color))

    @classmethod
    def hidden(cls):
        return cls(LinePlotConfig.hidden(),
                   LinePlotConfig.hidden(),
                   LinePlotConfig.hidden())


class FlatManifoldPlotConfig:
    pose_plot_config: PosePlotConfig
    poly_plot_config: PolyPlotConfig

    def __init__(self, pose_plot_config: PosePlotConfig, poly_plot_config: PolyPlotConfig):
        self.pose_plot_config = pose_plot_config
        self.poly_plot_config = poly_plot_config

    @classmethod
    def default(cls):
        return cls(PosePlotConfig.default(), PolyPlotConfig.from_color(Color.blue(), Color.black()))

    @classmethod
    def hide_pose(cls):
        return cls(PosePlotConfig.hidden(), PolyPlotConfig.from_color(Color.blue(), Color.black()))

    @classmethod
    def from_color(cls, face_color: Color, boundary_color: Color):
        return cls(PosePlotConfig.default(), PolyPlotConfig.from_color(face_color, boundary_color))


class WorkpiecePlotConfig:
    flat_manifold_plot_configs: List[FlatManifoldPlotConfig]
    pose_plot_config: PosePlotConfig

    def __init__(self, flat_manifold_plot_configs: List[FlatManifoldPlotConfig]):
        self.flat_manifold_plot_configs = flat_manifold_plot_configs
        self.pose_plot_config = PosePlotConfig.default()

    @ classmethod
    def default(cls, workpiece: Workpiece):
        return cls([FlatManifoldPlotConfig.hide_pose() for i in range(len(workpiece.slices))])

    @ classmethod
    def from_workpiece_and_color(cls, workpiece: Workpiece, color: Color):
        return cls([FlatManifoldPlotConfig.from_color(color, Color.black()) for i in range(len(workpiece.slices))])

    @ classmethod
    def from_workpiece_and_flat_manifold_plot_config(cls,
                                                     workpiece: Workpiece,
                                                     flatmanifold_config: FlatManifoldPlotConfig):
        return cls([flatmanifold_config for i in range(len(workpiece.slices))])

    @ classmethod
    def from_workpiece_and_callable(cls,
                                    workpiece: Workpiece,
                                    callable: Callable[[FlatManifold], FlatManifoldPlotConfig]):
        flat_manifold_plot_configs = [
            callable(flat_manifold) for flat_manifold in workpiece.slices]
        return cls(flat_manifold_plot_configs)


class BoxPlotConfig:
    poly_plot_config: PolyPlotConfig

    def __init__(self, surface_config: PolyPlotConfig):
        self.poly_plot_config = surface_config

    @ classmethod
    def default(cls):
        poly_config = PolyPlotConfig.default()
        poly_config.boundary = LinePlotConfig.default()
        return cls(poly_config)

    @ classmethod
    def from_color(cls, color: Color):
        poly_config = PolyPlotConfig.from_color(color, color)
        poly_config.boundary = LinePlotConfig.default()
        return cls(poly_config)


class MeshPlotConfig:
    pose_plot_config: PosePlotConfig
    poly_plot_config: PolyPlotConfig

    def __init__(self, pose_plot_config: PosePlotConfig, surface_config: PolyPlotConfig):
        self.pose_plot_config = pose_plot_config
        self.poly_plot_config = surface_config

    @ classmethod
    def default(cls):
        poly_config = PolyPlotConfig.default()
        poly_config.boundary = LinePlotConfig.default()
        return cls(PosePlotConfig.default(), poly_config)

    @ classmethod
    def from_color(cls, color: Color):
        poly_config = PolyPlotConfig.from_color(color, color)
        poly_config.boundary = LinePlotConfig.default()
        return cls(PosePlotConfig.default(), poly_config)


class GrainPlotConfig:
    pose_plot_config: PosePlotConfig
    poly_plot_config: PolyPlotConfig

    def __init__(self, mesh_plot_config: MeshPlotConfig):
        self.pose_plot_config = mesh_plot_config.pose_plot_config
        self.poly_plot_config = mesh_plot_config.poly_plot_config

    @ classmethod
    def default(cls):
        return cls(MeshPlotConfig.from_color(Color.magenta()))

    @ classmethod
    def from_color(cls, color: Color):
        return cls(MeshPlotConfig.from_color(color))

    @ classmethod
    def hidden_frame(cls):
        mesh_config = MeshPlotConfig.default()
        mesh_config.pose_plot_config = PosePlotConfig.hidden()
        return cls(mesh_config)


class ToolPlotConfig:
    grain_plot_configs: List[GrainPlotConfig]
    pose_plot_config: PosePlotConfig

    def __init__(self, grain_plot_configs: List[GrainPlotConfig]):
        self.grain_plot_configs = grain_plot_configs
        self.pose_plot_config = PosePlotConfig.default()

    @ classmethod
    def default(cls, tool: Tool):
        return cls([GrainPlotConfig.default() for i in range(len(tool.grains))])

    @ classmethod
    def from_tool_and_color(cls, tool: Tool, color: Color):
        return cls([GrainPlotConfig.from_color(color) for i in range(len(tool.grains))])

    @ classmethod
    def from_tool_and_grain_plot_config(cls, tool: Tool, grain_config: GrainPlotConfig):
        return cls([grain_config for i in range(len(tool.grains))])

    @ classmethod
    def from_tool_and_callable(cls, tool: Tool, callable: Callable[[Grain], GrainPlotConfig]):
        grain_plot_configs = [callable(grain) for grain in tool.grains]
        return cls(grain_plot_configs)


class TrajectoryPlotConfig:
    pose_plot_config: PosePlotConfig
    line_plot_config: LinePlotConfig

    def __init__(self, pose_plot_config: PosePlotConfig, line_plot_config: LinePlotConfig):
        self.pose_plot_config = pose_plot_config
        self.line_plot_config = line_plot_config

    @ classmethod
    def default(cls):
        return cls(PosePlotConfig.default(), LinePlotConfig(Color.black(), 2, Linestyle.solid, 1))


class KinematicsPlotConfig:
    trajectory_plot_config: TrajectoryPlotConfig

    def __init__(self, trajectory_plot_config: TrajectoryPlotConfig):
        self.trajectory_plot_config = trajectory_plot_config

    @ classmethod
    def default(cls):
        return cls(TrajectoryPlotConfig.default())


class StatePlotConfig:
    tool_plot_config: ToolPlotConfig
    workpiece_plot_config: WorkpiecePlotConfig

    def __init__(self, tool_plot_config: ToolPlotConfig,
                 workpiece_plot_config: WorkpiecePlotConfig):
        self.tool_plot_config = tool_plot_config
        self.workpiece_plot_config = workpiece_plot_config

    @ classmethod
    def default(cls, tool: Tool, workpiece: Workpiece):
        return cls(ToolPlotConfig.default(tool), WorkpiecePlotConfig.default(workpiece))


class ProcessPlotConfig:
    state_plot_config: StatePlotConfig
    kinematics_plot_config: KinematicsPlotConfig

    def __init__(self, state_plot_config: StatePlotConfig,
                 kinematics_plot_config: KinematicsPlotConfig):
        self.state_plot_config = state_plot_config
        self.kinematics_plot_config = kinematics_plot_config

    @ classmethod
    def default(cls, process: Process):
        return cls(StatePlotConfig.default(process.tool, process.workpiece), KinematicsPlotConfig.default())


class PointCloudPlotConfig:
    point_plot_configs: List[PointPlotConfig]

    def __init__(self, point_plot_configs: List[PointPlotConfig]):
        self.point_plot_configs = point_plot_configs

    @classmethod
    def default(cls, point_cloud: PointCloud):
        return cls([PointPlotConfig.default() for i in range(len(point_cloud.points))])

    @ classmethod
    def from_point_cloud_and_color(cls, point_cloud: PointCloud, color: Color):
        return cls([PointPlotConfig.from_color(color) for i in range(len(point_cloud.points))])

    @ classmethod
    def from_point_cloud_and_point_plot_config(cls, point_cloud: PointCloud,
                                               point_config: PointPlotConfig):
        return cls([point_config for i in range(len(point_cloud.points))])

    @ classmethod
    def from_point_cloud_and_callable(cls,
                                      point_cloud: PointCloud,
                                      callable: Callable[[Vector], PointPlotConfig]):
        point_cloud_plot_configs = [
            callable(point) for point in point_cloud.points]
        return cls(point_cloud_plot_configs)


class VisualComposition:
    polygons: List[PolygonVisualization]
    lines: List[LineVisualization]
    points: List[PointVisualization]

    def __init__(self,
                 polygons: List[PolygonVisualization],
                 lines: List[LineVisualization],
                 points: List[PointVisualization]):

        self.polygons = polygons
        self.lines = lines
        self.points = points

    @ classmethod
    def empty(cls):
        return cls([], [], [])

    def change_frame(self, down_chain, up_chain):
        polygons_on_new_frame = []
        lines_on_new_frame = []
        points_on_new_frame = []

        for polygon in self.polygons:
            new_vectors = Vector.change_frame_point_list(
                polygon.vectors, down_chain, up_chain)
            polygons_on_new_frame.append(
                PolygonVisualization(new_vectors, polygon.plot_config))
        for line in self.lines:
            new_vectors = Vector.change_frame_point_list(
                line.vectors, down_chain, up_chain)
            lines_on_new_frame.append(
                LineVisualization(new_vectors, line.plot_config))
        for point in self.points:
            new_vector = Vector.change_frame_point(
                point.vector, down_chain, up_chain)
            points_on_new_frame.append(
                PointVisualization(new_vector, point.plot_config))

        return VisualComposition(polygons_on_new_frame, lines_on_new_frame, points_on_new_frame)

    def combine(self, other):
        if isinstance(other, VisualComposition):

            combined_polygons = [*self.polygons, *other.polygons]
            combined_lines = [*self.lines, *other.lines]
            combined_points = [*self.points, *other.points]

            return VisualComposition(combined_polygons, combined_lines, combined_points)
        else:
            raise InputAreNotTheSameDataType
