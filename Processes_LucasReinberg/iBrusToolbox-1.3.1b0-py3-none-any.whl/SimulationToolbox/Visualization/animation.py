
from SimulationToolbox.Utilities.SimulationToolboxConfiguration import configuration
import matplotlib.animation as animation
import matplotlib.pyplot as plt
from SimulationToolbox.Visualization.visualization import *
from SimulationToolbox.PhysicalObjects.tool import *
from SimulationToolbox.PhysicalObjects.grain import *
from SimulationToolbox.PhysicalObjects import grain
from SimulationToolbox.Visualization.visualization_objects import GrainPlotConfig, ToolPlotConfig
from SimulationToolbox.Simulation.kinematics import Kinematics


def animation_data(composition: VisualComposition):

    vertices_for_scale = []
    data = []
    for polygon in composition.polygons:
        current_polygon_vertices = []
        for vertex in polygon.vectors:
            current_polygon_vertices.append(vertex.value[:3])
        vertices_for_scale.extend(current_polygon_vertices)
        config = polyplotconfig_to_matplotlib(polygon.plot_config)
        current_polygon = mplot3d.art3d.Poly3DCollection([current_polygon_vertices],
                                                         facecolors=config['face_color'],
                                                         edgecolors=config['edge_color'],
                                                         linewidths=config['linewidth'],
                                                         linestyles=config['linestyle'],
                                                         alpha=config['alpha'])

        data.append(current_polygon)

    line_data = []
    for line in composition.lines:
        current_line_vertices = []
        for vertex in line.vectors:
            current_line_vertices.append(vertex.value[:3])
        vertices_for_scale.extend(current_line_vertices)
        config = lineplotconfig_to_matplotlib(line.plot_config)
        current_line = mplot3d.art3d.Line3DCollection(
            [current_line_vertices], colors=config['color'],
            linewidths=config['linewidth'],
            linestyles=config['linestyle'],
            alpha=config['alpha'])
        data.append(current_line)

    return [data, vertices_for_scale]


def animate_process(tools: List[Tool], workpieces: List[Workpiece], kinematics: Kinematics,
                    title: str = 'Process Animation', axis_labels: List[str] = ['x axis', 'y axis', 'z axis'],
                    length_unit: str = '(m)', save_path: str = r"./Process_simulation.mp4"):
    """To animate a process, the workpiece and tool objects at each step of process and the kinematics
    is required."""

    fig = plt.figure()
    ax = fig.add_subplot(projection='3d')

    state_of_sim = animation_data(visualize_state_of_simulation(
        tools[0].move(kinematics.ToolTrajectory.poses[0]), workpieces[0], StatePlotConfig.default(tools[0].move(kinematics.ToolTrajectory.poses[0]), workpieces[0])))
    faces = state_of_sim[0]
    for face in faces:
        ax.add_collection3d(face)
    scale = np.array(state_of_sim[1]).flatten('F')
    ax.auto_scale_xyz(scale, scale, scale)

    ax.set_title(title)
    ax.set_xlabel(axis_labels[0] + ' ' + length_unit)
    ax.set_ylabel(axis_labels[1] + ' ' + length_unit)
    ax.set_zlabel(axis_labels[2] + ' ' + length_unit)

    def update_figure(figure_no: int):
        state_of_sim = animation_data(visualize_state_of_simulation(
            tools[figure_no].move(
                kinematics.ToolTrajectory.poses[figure_no]), workpieces[figure_no],
            StatePlotConfig.default(tools[figure_no].move(kinematics.ToolTrajectory.poses[figure_no]),
                                    workpieces[figure_no])))
        faces = state_of_sim[0]
        ax.collections = []
        for face in faces:
            ax.add_collection3d(face)

    process_animation = animation.FuncAnimation(fig, update_figure, frames=range(0, len(kinematics.ToolTrajectory.poses)),
                                                interval=200, blit=False, repeat=False)

    # plt.show()

    writer = animation.FFMpegWriter(fps=7, bitrate=7000)
    process_animation.save(save_path, writer=writer)
