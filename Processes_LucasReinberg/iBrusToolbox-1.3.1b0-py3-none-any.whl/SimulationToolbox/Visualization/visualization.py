"""This file contains a general visulization module to plot different
objects in the simulation"""
from os.path import splitext
from copy import deepcopy
from SimulationToolbox.Geometry.geometry import *
from SimulationToolbox.Geometry.geometric_objects import *
from SimulationToolbox.Simulation.process import *
from SimulationToolbox.PhysicalObjects.workpiece import *
from SimulationToolbox.PhysicalObjects.grain import *
from SimulationToolbox.PhysicalObjects.tool import *
from SimulationToolbox.Visualization.visualization_objects import *
from SimulationToolbox.Utilities.SimulationToolboxConfiguration import *
from typing import *
from typing import Mapping, Callable
import numpy as np
from matplotlib import pyplot as plt
from mpl_toolkits import mplot3d
import plotly.graph_objects as go


def visualize_pose(pose: Pose, plot_config: PosePlotConfig, scale: float) -> VisualComposition:

    visual_composition = VisualComposition.empty()
    line_list = []

    axis_x = [Vector.origin().change_frame_point([pose], []),
              (Vector.e_x().scale(scale)).change_frame_point([pose], [])]
    axis_y = [Vector.origin().change_frame_point([pose], []),
              (Vector.e_y().scale(scale)).change_frame_point([pose], [])]
    axis_z = [Vector.origin().change_frame_point([pose], []),
              (Vector.e_z().scale(scale)).change_frame_point([pose], [])]

    line_list.append(LineVisualization(axis_x, plot_config.x_config))
    line_list.append(LineVisualization(axis_y, plot_config.y_config))
    line_list.append(LineVisualization(axis_z, plot_config.z_config))
    visual_composition = visual_composition.combine(VisualComposition(
        [], line_list, []))

    return visual_composition


def visualize_flat_manifold(flat_manifold: FlatManifold, plot_config: FlatManifoldPlotConfig) \
        -> VisualComposition:

    exterior_points = flat_manifold.area.to_line2d()

    vertices_as_vectors = []
    for point_idx in range(len(exterior_points.x_values)):
        vertices_as_vectors.append(
            Vector(exterior_points.x_values[point_idx], 0, exterior_points.z_values[point_idx]))

    pose_scale = get_bounding_sphere_radius(
        vertices_as_vectors)
    pose_composition = visualize_pose(
        Pose.identity(), plot_config.pose_plot_config, pose_scale)
    manifold_composition = pose_composition.combine(VisualComposition(
        [PolygonVisualization(vertices_as_vectors, plot_config.poly_plot_config)], [], []))

    return manifold_composition.change_frame([flat_manifold.pose], [])


def visualize_workpiece(workpiece: Workpiece, plot_config: WorkpiecePlotConfig)\
        -> VisualComposition:

    if len(workpiece.slices) != len(plot_config.flat_manifold_plot_configs):
        raise Exception(
            'Number of manifold plot configurations in workpiece plot config \
                must be equal to number of slices')

    workpiece_composition = VisualComposition.empty()

    for i in range(len(workpiece.slices)):
        slice_composition = visualize_flat_manifold(
            workpiece.slices[i], plot_config.flat_manifold_plot_configs[i])
        workpiece_composition = workpiece_composition.combine(
            slice_composition.change_frame([workpiece.pose], []))
    # TODO calculate pose size
    workpiece_composition = workpiece_composition.combine(
        visualize_pose(workpiece.pose, plot_config.pose_plot_config, 10))
    return workpiece_composition


def visualize_box(box: Box, plot_config: BoxPlotConfig):
    polygon_visualizations = []
    p1 = Vector(box.x_max, box.y_min, box.z_min)
    p2 = Vector(box.x_max, box.y_max, box.z_min)
    p3 = Vector(box.x_min, box.y_max, box.z_min)
    p4 = Vector(box.x_min, box.y_min, box.z_min)
    p5 = Vector(box.x_max, box.y_min, box.z_max)
    p6 = Vector(box.x_max, box.y_max, box.z_max)
    p7 = Vector(box.x_min, box.y_max, box.z_max)
    p8 = Vector(box.x_min, box.y_min, box.z_max)
    # bottom
    polygon_visualizations.append(PolygonVisualization(
        [p1, p2, p3, p4], plot_config.poly_plot_config))
    # right
    polygon_visualizations.append(PolygonVisualization(
        [p1, p2, p6, p5], plot_config.poly_plot_config))
    # back
    polygon_visualizations.append(PolygonVisualization(
        [p2, p6, p7, p3], plot_config.poly_plot_config))
    # left
    polygon_visualizations.append(PolygonVisualization(
        [p4, p3, p7, p8], plot_config.poly_plot_config))
    # front
    polygon_visualizations.append(PolygonVisualization(
        [p4, p1, p5, p8], plot_config.poly_plot_config))
    # top
    polygon_visualizations.append(PolygonVisualization(
        [p5, p6, p7, p8], plot_config.poly_plot_config))

    return VisualComposition(polygon_visualizations, [], []).change_frame([box.pose], [])


def visualize_mesh(mesh: Mesh, plot_config: MeshPlotConfig) -> VisualComposition:

    polygons = []
    for triangle in mesh.triangle_indices:
        polygon_vertices = []
        for index in triangle:
            polygon_vertices.append(mesh.vertices[index])
        polygons.append(PolygonVisualization(
            polygon_vertices, plot_config.poly_plot_config))

    pose_scale = mesh.get_bounding_sphere().radius
    pose_composition = visualize_pose(
        Pose.identity(), plot_config.pose_plot_config, pose_scale)
    triangle_composition = VisualComposition(polygons, [], [])
    mesh_plot_composition = pose_composition.combine(triangle_composition)

    return mesh_plot_composition


def visualize_grain(grain: Grain, plot_config: GrainPlotConfig) -> VisualComposition:
    mesh_plot_composition = visualize_mesh(grain.get_mesh(), plot_config)
    return mesh_plot_composition.change_frame([grain.pose], [])


def visualize_tool(tool: Tool, plot_config: ToolPlotConfig) -> VisualComposition:

    if len(tool.grains) != len(plot_config.grain_plot_configs):
        raise Exception(
            'Number of grain plot configurations in tool plot \
                config must be equal to number of grains')

    tool_plot_composition = VisualComposition.empty()

    for i in range(len(tool.grains)):
        if not tool.grains[i].pullout:
            grain_composition = visualize_grain(
                tool.grains[i], plot_config.grain_plot_configs[i])
            tool_plot_composition = tool_plot_composition.combine(
                grain_composition.change_frame([tool.pose], []))

    tool_size = tool.get_max_bounding_sphere_radius()
    tool_plot_composition = tool_plot_composition.combine(
        visualize_pose(tool.pose, plot_config.pose_plot_config, tool_size))

    return tool_plot_composition


def visualize_state_of_simulation(tool: Tool, workpiece: Workpiece, plot_config: StatePlotConfig) \
        -> VisualComposition:

    state_composition = VisualComposition.empty()

    tool_composition = visualize_tool(tool, plot_config.tool_plot_config)
    state_composition = state_composition.combine(tool_composition)

    workpiece_composition = visualize_workpiece(
        workpiece, plot_config.workpiece_plot_config)
    state_composition = state_composition.combine(workpiece_composition)

    return state_composition


def visualize_trajectory(trajectory: PoseTrajectory,
                         plot_config: TrajectoryPlotConfig, pose_scale: float) -> VisualComposition:

    trajectory_composition = VisualComposition.empty()
    pose_positions = []

    for pose in trajectory.poses:
        pose_positions.append(pose.get_position())
        pose_composition = visualize_pose(
            pose, plot_config.pose_plot_config, pose_scale)
        trajectory_composition = trajectory_composition.combine(
            pose_composition)

    line = LineVisualization(pose_positions, plot_config.line_plot_config)
    trajectory_composition = trajectory_composition.combine(
        VisualComposition([], [line], []))

    return trajectory_composition


def visualize_kinematics(kinematics: Kinematics, plot_config: KinematicsPlotConfig, pose_scale: float) -> VisualComposition:
    return visualize_trajectory(
        kinematics.ToolTrajectory, plot_config.trajectory_plot_config, pose_scale)


def visualize_process(process: Process, plot_config: ProcessPlotConfig, kinematics_idx=0) -> VisualComposition:

    process_composition = VisualComposition.empty()

    state_composition = visualize_state_of_simulation(
        process.tool.move(process.kinematics.ToolTrajectory.poses[kinematics_idx]), process.workpiece, plot_config.state_plot_config)
    process_composition = process_composition.combine(state_composition)

    kinematics_composition = visualize_kinematics(
        process.kinematics,
        plot_config.kinematics_plot_config, 1)  # TODO make dynamic control of pose size

    process_composition = process_composition.combine(kinematics_composition)

    return process_composition


def visualize_point_cloud(point_cloud: PointCloud, plot_config: PointCloudPlotConfig) \
        -> VisualComposition:

    point_cloud_composition = VisualComposition.empty()
    point_composition_list = []
    for point_no, point in enumerate(point_cloud.points):
        point_composition_list.append(PointVisualization(
            point, plot_config.point_plot_configs[point_no]))

    point_cloud_composition = point_cloud_composition.combine(
        VisualComposition([], [], point_composition_list))

    return point_cloud_composition


class PlotLibrary(enum.Enum):
    matplot_lib = 1
    plotly = 2


# TODO implement user API like this on all vis_methods
# TODO wherever default values are used make a deepcopy of it before using


def plot_pose(pose: Pose, plot_config: PosePlotConfig = PosePlotConfig.default(),
              scale: float = 1,
              library: PlotLibrary = PlotLibrary.matplot_lib,
              title: str = 'Pose Plot',
              axis_labels: List[str] = ['x axis', 'y axis', 'z axis'],
              length_unit: str = '(m)',
              save_path: str = 'None',
              dpi: int = 600):

    vis = visualize_pose(pose, copy.deepcopy(
        plot_config), copy.deepcopy(scale))
    plot(vis, title, axis_labels, length_unit,
         copy.deepcopy(library), save_path, dpi)


def plot_flat_manifold(flat_manifold: FlatManifold,
                       plot_config: FlatManifoldPlotConfig = FlatManifoldPlotConfig.default(),
                       library: PlotLibrary = PlotLibrary.matplot_lib,
                       title: str = 'Flat Manifold Plot',
                       axis_labels: List[str] = ['x axis', 'y axis', 'z axis'],
                       length_unit: str = '(m)',
                       save_path: str = 'None',
                       dpi: int = 600):

    vis = visualize_flat_manifold(flat_manifold,  copy.deepcopy(plot_config))
    plot(vis, title, axis_labels, length_unit,
         copy.deepcopy(library), save_path, dpi)


def plot_workpiece(workpiece: Workpiece,
                   plot_config: WorkpiecePlotConfig,
                   library: PlotLibrary = PlotLibrary.matplot_lib,
                   title: str = 'Workpiece Plot',
                   axis_labels: List[str] = ['x axis', 'y axis', 'z axis'],
                   length_unit: str = '(m)',
                   save_path: str = 'None',
                   dpi: int = 600):

    vis = visualize_workpiece(workpiece, plot_config)
    plot(vis, title, axis_labels, length_unit,
         copy.deepcopy(library), save_path, dpi)


# TODO: plot_box should take the level of boxes and plot the desired level
def plot_box(box: Box,
             plot_config: BoxPlotConfig = BoxPlotConfig.default(),
             library: PlotLibrary = PlotLibrary.matplot_lib,
             title: str = 'Box Plot',
             axis_labels: List[str] = ['x axis', 'y axis', 'z axis'],
             length_unit: str = '(m)'):
    vis = visualize_box(box,  copy.deepcopy(plot_config))
    plot(vis, title, axis_labels, length_unit, copy.deepcopy(library))


def plot_mesh(mesh: Mesh,
              plot_config: MeshPlotConfig = MeshPlotConfig.default(),
              library: PlotLibrary = PlotLibrary.matplot_lib,
              title: str = 'Mesh Plot',
              axis_labels: List[str] = ['x axis', 'y axis', 'z axis'],
              length_unit: str = '(m)',
              save_path: str = 'None',
              dpi: int = 600):

    vis = visualize_mesh(mesh,  copy.deepcopy(plot_config))
    plot(vis, title, axis_labels, length_unit,
         copy.deepcopy(library), save_path, dpi)


def plot_grain(grain: Grain,
               plot_config: GrainPlotConfig = GrainPlotConfig.default(),
               library: PlotLibrary = PlotLibrary.matplot_lib,
               title: str = 'Grain Plot',
               axis_labels: List[str] = ['x axis', 'y axis', 'z axis'],
               length_unit: str = '(m)',
               save_path: str = 'None',
               dpi: int = 600):

    vis = visualize_grain(grain,  copy.deepcopy(plot_config))
    plot(vis, title, axis_labels, length_unit,
         copy.deepcopy(library), save_path, dpi)


def plot_tool(tool: Tool,
              plot_config: ToolPlotConfig,
              library: PlotLibrary = PlotLibrary.matplot_lib,
              title: str = 'Tool Plot',
              axis_labels: List[str] = ['x axis', 'y axis', 'z axis'],
              length_unit: str = '(m)',
              save_path: str = 'None',
              dpi: int = 600):

    vis = visualize_tool(tool, plot_config)
    plot(vis, title, axis_labels, length_unit,
         copy.deepcopy(library), save_path, dpi)


def plot_state_of_simulation(tool: Tool,
                             workpiece: Workpiece,
                             plot_config: StatePlotConfig,
                             library: PlotLibrary = PlotLibrary.matplot_lib,
                             title: str = 'State of Simulation Plot',
                             axis_labels: List[str] = [
                                 'x axis', 'y axis', 'z axis'],
                             length_unit: str = '(m)',
                             save_path: str = 'None',
                             dpi: int = 600):

    vis = visualize_state_of_simulation(tool, workpiece, plot_config)
    plot(vis, title, axis_labels, length_unit,
         copy.deepcopy(library), save_path, dpi)


def plot_trajectory(trajectory: PoseTrajectory,
                    plot_config: TrajectoryPlotConfig = TrajectoryPlotConfig.default(),
                    pose_scale: float = 1,
                    library: PlotLibrary = PlotLibrary.matplot_lib,
                    title: str = 'Trajectory Plot',
                    axis_labels: List[str] = ['x axis', 'y axis', 'z axis'],
                    length_unit: str = '(m)',
                    save_path: str = 'None',
                    dpi: int = 600):

    vis = visualize_trajectory(trajectory,  copy.deepcopy(
        plot_config), copy.deepcopy(pose_scale))
    plot(vis, title, axis_labels, length_unit,
         copy.deepcopy(library), save_path, dpi)


def plot_kinematics(kinematics: Kinematics,
                    plot_config: KinematicsPlotConfig = KinematicsPlotConfig.default(),
                    pose_scale: float = 1,
                    library: PlotLibrary = PlotLibrary.matplot_lib,
                    title: str = 'Kinematics Plot',
                    axis_labels: List[str] = ['x axis', 'y axis', 'z axis'],
                    length_unit: str = '(m)',
                    save_path: str = 'None',
                    dpi: int = 600):

    vis = visualize_kinematics(kinematics,  copy.deepcopy(
        plot_config), pose_scale)
    plot(vis, title, axis_labels, length_unit,
         copy.deepcopy(library), save_path, dpi)


def plot_process(process: Process,
                 plot_config: ProcessPlotConfig,
                 library: PlotLibrary = PlotLibrary.matplot_lib, kinematics_idx=0,
                 title: str = 'Process Plot',
                 axis_labels: List[str] = ['x axis', 'y axis', 'z axis'],
                 length_unit: str = '(m)',
                 save_path: str = 'None',
                 dpi: int = 600):

    vis = visualize_process(process,  plot_config, kinematics_idx)
    plot(vis, title, axis_labels, length_unit,
         copy.deepcopy(library), save_path, dpi)


def plot_grain_trajectory(process: Process,
                          grain_index: int,
                          plot_config: ProcessPlotConfig,
                          library: PlotLibrary = PlotLibrary.matplot_lib,
                          kinematics_idx=0,
                          title: str = 'Grain Trajectory Plot',
                          axis_labels: List[str] = [
                              'x axis', 'y axis', 'z axis'],
                          length_unit: str = '(m)',
                          save_path: str = 'None',
                          dpi: int = 600):

    # get the grain trajectory
    grain = process.tool.grains[grain_index]
    grain_trajectory: List[Vector] = []
    for tool_pose in process.kinematics.ToolTrajectory.poses:
        grain_trajectory.append(
            grain.get_position().change_frame_point([tool_pose], []))

    line_plot_config = LinePlotConfig.default()
    line_plot_config.linewidth = 3
    graintrajectory_line_viz = LineVisualization(
        grain_trajectory, line_plot_config)
    graintrajectory_viz = VisualComposition([], [graintrajectory_line_viz], [])
    trajectory_vis = vis = visualize_trajectory(
        process.kinematics.ToolTrajectory,  TrajectoryPlotConfig.default(), 1)
    wp_vis = visualize_workpiece(
        process.workpiece, WorkpiecePlotConfig.default(process.workpiece))
    vis = graintrajectory_viz.combine(trajectory_vis).combine(wp_vis)
    plot(vis, title, axis_labels, length_unit,
         copy.deepcopy(library), save_path, dpi)


def plot_point_cloud(point_cloud: PointCloud,
                     plot_config: PointCloudPlotConfig,
                     library: PlotLibrary = PlotLibrary.matplot_lib,
                     title: str = 'Point Cloud Plot',
                     axis_labels: List[str] = ['x axis', 'y axis', 'z axis'],
                     length_unit: str = '(m)',
                     save_path: str = 'None',
                     dpi: int = 600):

    vis = visualize_point_cloud(point_cloud,  plot_config)
    plot(vis, title, axis_labels, length_unit,
         copy.deepcopy(library), save_path, dpi)


def plot(composition: VisualComposition,
         title: str, axis_labels: List[str], length_unit: str,
         plotlibrary: PlotLibrary = PlotLibrary.matplot_lib,
         save_path: str = 'None', dpi: int = 600):

    if plotlibrary == PlotLibrary.matplot_lib:
        plt.figure()
        ax = plt.axes(projection='3d')
        vertices_for_scale = []

        for polygon in composition.polygons:
            current_polygon_vertices = []
            for vertex in polygon.vectors:
                current_polygon_vertices.append(vertex.value[:3])
            vertices_for_scale.extend(current_polygon_vertices)
            config = polyplotconfig_to_matplotlib(polygon.plot_config)
            current_polygon = mplot3d.art3d.Poly3DCollection([current_polygon_vertices],
                                                             facecolors=config['face_color'],
                                                             edgecolors=config['edge_color'],
                                                             linewidths=config['linewidth'],
                                                             linestyles=config['linestyle'],
                                                             alpha=config['alpha'])
            ax.add_collection3d(current_polygon)

        for line in composition.lines:
            current_line_vertices = []
            for vertex in line.vectors:
                current_line_vertices.append(vertex.value[:3])
            vertices_for_scale.extend(current_line_vertices)
            config = lineplotconfig_to_matplotlib(line.plot_config)
            current_line = mplot3d.art3d.Line3DCollection(
                [current_line_vertices], colors=config['color'],
                linewidths=config['linewidth'],
                linestyles=config['linestyle'],
                alpha=config['alpha'])
            ax.add_collection3d(current_line)

        for point in composition.points:
            vertices_for_scale.append(point.vector.value[:3])
            config = pointplotconfig_to_matplotlib(point.plot_config)
            ax.scatter(point.vector.value[0], point.vector.value[1], point.vector.value[2],
                       c=config['color'], alpha=config['alpha'], marker=config['marker'])

        ax.set_title(title)
        ax.set_xlabel(axis_labels[0] + ' ' + length_unit)
        ax.set_ylabel(axis_labels[1] + ' ' + length_unit)
        ax.set_zlabel(axis_labels[2] + ' ' + length_unit)

        scale = np.array(vertices_for_scale).flatten('F')
        ax.auto_scale_xyz(scale, scale, scale)

        # Hide grid lines
        # ax.grid(False)

        # Hide axes ticks
        # ax.set_xticks([])
        # ax.set_yticks([])
        # ax.set_zticks([])

        # plt.axis('off')

        if configuration.do_plot:
            plt.show()

        if save_path != 'None':
            plt.savefig(save_path, bbox_inches=None, dpi=dpi)

    elif plotlibrary == PlotLibrary.plotly:
        fig = go.Figure()
        vertices_for_scale = []

        for polygon in composition.polygons:
            vertices_x = []
            vertices_y = []
            vertices_z = []
            current_polygon_vertices = []
            for vertex in polygon.vectors:
                vertices_x.append(vertex.x())
                vertices_y.append(vertex.y())
                vertices_z.append(vertex.z())
                current_polygon_vertices.append(vertex.value[:3])
            vertices_for_scale.extend(current_polygon_vertices)
            config = polyplotconfig_to_plotly(polygon.plot_config)

            polygon_vector_1 = polygon.vectors[1].subtract(polygon.vectors[0])
            polygon_vector_2 = polygon.vectors[2].subtract(polygon.vectors[0])
            polygon_normal = polygon_vector_1.cross(polygon_vector_2)

            dot_x = np.abs(polygon_normal.dot(Vector.e_x()))
            dot_y = np.abs(polygon_normal.dot(Vector.e_y()))
            dot_z = np.abs(polygon_normal.dot(Vector.e_z()))

            if max([dot_x, dot_y, dot_z]) == dot_x:
                delaunayaxis = 'x'
            elif max([dot_x, dot_y, dot_z]) == dot_y:
                delaunayaxis = 'y'
            elif max([dot_x, dot_y, dot_z]) == dot_z:
                delaunayaxis = 'z'
            else:
                raise Exception(
                    'Unknown error in determination of delaunayaxis')

            fig.add_trace(go.Mesh3d(x=vertices_x, y=vertices_y, z=vertices_z,
                                    delaunayaxis=delaunayaxis,
                                    opacity=config['opacity'],
                                    color=config['face_color']))
            fig.add_trace(go.Scatter3d(x=vertices_x, y=vertices_y, z=vertices_z, mode='lines',
                                       line=dict(color=config['edge_color'],
                                                 width=config['linewidth'],
                                                 dash=config['linestyle']),
                                       opacity=config['opacity']))

        for line in composition.lines:
            vertices_x = []
            vertices_y = []
            vertices_z = []
            current_line_vertices = []
            for vertex in line.vectors:
                vertices_x.append(vertex.x())
                vertices_y.append(vertex.y())
                vertices_z.append(vertex.z())
                current_line_vertices.append(vertex.value[:3])
            vertices_for_scale.extend(current_line_vertices)
            config = lineplotconfig_to_plotly(line.plot_config)
            fig.add_trace(go.Scatter3d(x=vertices_x, y=vertices_y, z=vertices_z, mode='lines',
                                       line=dict(color=config['color'],
                                                 width=config['linewidth'],
                                                 dash=config['linestyle']),
                                       opacity=config['opacity']))

        for point in composition.points:
            vertices_for_scale.append(point.vector.value[:3])
            config = pointplotconfig_to_plotly(point.plot_config)
            fig.add_trace(go.Scatter3d(x=np.array(point.vector.x()),
                                       y=np.array(point.vector.y()),
                                       z=np.array(point.vector.z()),
                                       marker=dict(
                color=config['color'],
                symbol=config['marker']),
                opacity=config['opacity']))

        scale = np.array(vertices_for_scale).flatten('F')
        # Axis ranges extended 5 % for easier visualization
        fig.update_layout(title=dict(text=title, x=0.5),
                          scene=dict(
            xaxis=dict(title=dict(
                text=axis_labels[0] + ' ' + length_unit), range=[min(scale)*1.05, max(scale)*1.05]),
            yaxis=dict(title=dict(
                text=axis_labels[1] + ' ' + length_unit), range=[min(scale)*1.05, max(scale)*1.05]),
            zaxis=dict(title=dict(text=axis_labels[2] + ' ' + length_unit), range=[min(scale)*1.05, max(scale)*1.05])))
        fig.update_scenes(aspectmode='cube')
        if configuration.do_plot:
            fig.show()

        if save_path != 'None':
            root = splitext(save_path)[0]
            fig.write_html(root + '.html')
    else:
        raise Exception('Specified library is not supported')


def pointplotconfig_to_matplotlib(plot_config: PointPlotConfig) -> dict:
    config = {}

    config['color'] = [(plot_config.color.r,
                        plot_config.color.g,
                        plot_config.color.b,
                        plot_config.color.alpha)]
    config['alpha'] = plot_config.alpha

    if plot_config.marker.value == 1:
        config['marker'] = 'o'
    elif plot_config.marker.value == 2:
        config['marker'] = 's'
    elif plot_config.marker.value == 3:
        config['marker'] = 'x'
    elif plot_config.marker.value == 4:
        config['marker'] = '.'
    else:
        raise Exception(
            'Support of marker type for matplotlib is not establised or not possible')

    return config


def lineplotconfig_to_matplotlib(plot_config: LinePlotConfig) -> dict:
    config = {}

    config['alpha'] = plot_config.alpha
    config['color'] = [(plot_config.color.r,
                        plot_config.color.g,
                        plot_config.color.b,
                        plot_config.color.alpha)]
    config['linewidth'] = plot_config.linewidth
    if plot_config.style.value == 1:
        config['linestyle'] = 'solid'
    elif plot_config.style.value == 2:
        config['linestyle'] = 'dotted'
    elif plot_config.style.value == 3:
        config['linestyle'] = 'dashed'
    else:
        raise Exception(
            'Support of line type for matplotlib is not establised or not possible')

    return config


def polyplotconfig_to_matplotlib(plot_config: PolyPlotConfig) -> dict:
    config = {}

    config['alpha'] = plot_config.alpha
    config['face_color'] = [(plot_config.face_color.r,
                             plot_config.face_color.g,
                             plot_config.face_color.b,
                             plot_config.face_color.alpha)]
    config['edge_color'] = [(plot_config.boundary.color.r,
                             plot_config.boundary.color.g,
                             plot_config.boundary.color.b,
                             plot_config.boundary.color.alpha)]
    config['linewidth'] = plot_config.boundary.linewidth
    if plot_config.boundary.style.value == 1:
        config['linestyle'] = 'solid'
    elif plot_config.boundary.style.value == 2:
        config['linestyle'] = 'dotted'
    elif plot_config.boundary.style.value == 3:
        config['linestyle'] = 'dashed'
    else:
        raise Exception(
            'Support of line type for matplotlib is not establised or not possible')

    return config


def pointplotconfig_to_plotly(plot_config: PointPlotConfig) -> dict:
    config = {}

    config['opacity'] = plot_config.alpha
    config['color'] = f'rgb({plot_config.color.r*255},\
        {plot_config.color.g*255},{plot_config.color.b*255})'
    if plot_config.marker.value == 1:
        config['marker'] = 'circle'
    elif plot_config.marker.value == 2:
        config['marker'] = 'square'
    elif plot_config.marker.value == 3:
        config['marker'] = 'x'
    else:
        raise Exception(
            'Support of marker type for plotly is not establised or not possible')
    return config


def lineplotconfig_to_plotly(plot_config: LinePlotConfig) -> dict:
    config = {}

    config['opacity'] = plot_config.alpha
    config['color'] = f'rgb({plot_config.color.r*255},\
        {plot_config.color.g*255},{plot_config.color.b*255})'
    config['linewidth'] = plot_config.linewidth

    if plot_config.style.value == 1:
        config['linestyle'] = 'solid'
    elif plot_config.style.value == 2:
        config['linestyle'] = 'dot'
    elif plot_config.style.value == 3:
        config['linestyle'] = 'dash'
    else:
        raise Exception(
            'Support of line type for plotly is not establised or not possible')

    return config


def polyplotconfig_to_plotly(plot_config: PolyPlotConfig) -> dict:
    config = {}

    config['face_color'] = f'rgb({plot_config.face_color.r*255},\
        {plot_config.face_color.g*255},{plot_config.face_color.b*255})'
    config['opacity'] = plot_config.alpha
    config['edge_color'] = f'rgb({plot_config.boundary.color.r*255},\
        {plot_config.boundary.color.g*255},{plot_config.boundary.color.b*255})'
    config['linewidth'] = plot_config.boundary.linewidth
    if plot_config.boundary.style.value == 1:
        config['linestyle'] = 'solid'
    elif plot_config.boundary.style.value == 2:
        config['linestyle'] = 'dot'
    elif plot_config.boundary.style.value == 3:
        config['linestyle'] = 'dash'
    else:
        raise Exception(
            'Support of line type for plotly is not establised or not possible')

    return config
