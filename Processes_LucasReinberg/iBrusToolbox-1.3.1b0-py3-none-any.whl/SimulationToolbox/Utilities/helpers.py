import numpy as np
from collections.abc import Iterable

np.random.seed(0)
r_nrs = np.random.rand(100)
default_precision = 1e-10
wp_slice_precision = 1e-3


def compare_np_arrays(array_1: np.ndarray, array_2: np.ndarray, precision: float):
    number_of_decimals_in_precision = -int(np.log10(precision))
    np.testing.assert_array_almost_equal(
        array_1, array_2, number_of_decimals_in_precision)


def flatten_list(nested_list: list):
    '''A very useful helper function to flatten out arbitrarily nested python list. 
    To get the list from the result, do:  list(flatten_list(nested_list))
    '''
    for element in nested_list:
        if isinstance(element, Iterable) and not isinstance(element, (str, bytes)):
            yield from flatten_list(element)
        else:
            yield element


def remove_objects_from_list(list, object_removal_bool_list):
    list[:] = [element for idx, element in enumerate(
        list) if not object_removal_bool_list[idx]]


class OptionalAttributeNotCalculatedYet(Exception):
    pass


class InputAreNotTheSameDataType(Exception):
    pass


class ShapelyErrorWillOccur(Exception):
    pass
