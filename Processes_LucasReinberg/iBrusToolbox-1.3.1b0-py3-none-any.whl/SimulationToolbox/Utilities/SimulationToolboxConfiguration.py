class configuration:
    do_plot = False
