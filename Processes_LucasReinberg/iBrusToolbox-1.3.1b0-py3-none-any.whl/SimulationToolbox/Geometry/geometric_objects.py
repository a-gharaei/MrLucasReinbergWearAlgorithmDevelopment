from __future__ import annotations
import numpy as np
from typing import *
import copy
from typing import Mapping, Callable
from pygeos.creation import _xyz_to_coords
import stl
from pygeos.measurement import area, distance
from SimulationToolbox.Geometry.geometry import *
import dill

'''
Geometric Objects are Objects in 3D space possibly sharing the following structure:

obj.pose:                   defining the pose of the object
obj.internal_values:        represented in the pose-frame
obj.move(pose):             moves the object to the pose passed
obj.transform(transform):   transforms the internal values with the given transform
                            the transform needs to be represented in the pose-frame
obj.represent_in_pose_frame(pose):
                            represents the internal-values in the frame defined by
                            the given pose, and sets self.pose=pose
obj.compare(other,precision):
                            compares the object to other and raises if they are not
                            equal up to the given precision


Implementation Remark:  Objects with proximity-callable  passed from external should
                        not be moved after definition, since otherwhise the proximity
                        does not match
                        !!Currently we do not support moving proximities!!

'''


# TODO discuss: define a message/result class and put it there
# TODO: unify the proximity result class with PointProximityResult


class RegisteredAreaOnPlane:
    plane_index: int  # index of the plane in workpiece slices list
    area: Area2D
    # registered position of the projected area on the plane, in workpiece frame.
    registered_position_in_wp_frame: Vector

    def __init__(self, plane_index: int, area: Area2D):
        self.plane_index = plane_index
        self.area = area


class VolumeProximityResult:
    """This class stores the volume proximity results.
    VolumeProximityResult.is_in_proximity returns bool """
    is_in_proximity: bool

    def __init__(self, is_in_proximity: bool):
        self.is_in_proximity = is_in_proximity


class FlatManifoldProximityResult:
    """This class stores the proximity result between grain and a FlatManifold:
    1. If a grain is_in_proximity,
    2, If a grain is_on_frontside,
    3. If a grain is_on_backside
    """
    is_in_proximity: bool
    is_on_frontside: bool
    is_on_backside: bool

    def __init__(self, is_inside: bool, point_is_on_frontside: bool,
                 point_is_on_backside: bool):
        self.is_in_proximity = is_inside
        self.is_on_frontside = point_is_on_frontside
        self.is_on_backside = point_is_on_backside


class Sphere:
    """A sphere defined by center and radius.
    Currently, it's used to construct a bouding_sphere_radius
    of a grain."""
    center:  Vector
    radius: float

    def __init__(self, center: Vector, radius: float):
        self.center = center
        self.radius = radius


class PointCloud:
    points: List[Vector]
    pose: Pose

    def __init__(self, vectors_list: List[Vector], pose: Pose):
        self.points = vectors_list
        self.pose = pose

    @classmethod
    def from_points_in_array(cls, points_in_array, pose):
        vectors_list = [Vector(item[0], item[1], item[2])
                        for item in points_in_array]
        return cls(vectors_list, pose)

    @classmethod
    def from_flatmanifold(cls, flatmanifold):
        return cls(flatmanifold.get_boundary_points_in_base_frame(),
                   flatmanifold.pose)

    @classmethod
    def from_tool(cls, tool):
        point_list = []
        for grain in tool.grains:
            point_list.append(grain.get_position())
        return cls(point_list, tool.pose)

    @classmethod
    def unique_merge(cls, PC1, PC2):
        if PC1.pose.compare(PC2.pose, precision=default_precision) is None:
            a = np.ascontiguousarray(np.concatenate(
                (PC1.in_array(), PC2.in_array()), axis=0))
            unique_a = np.unique(a.view([('', a.dtype)] * a.shape[1]))
            points_in_array = unique_a.view(a.dtype).reshape(
                (unique_a.shape[0], a.shape[1]))
            return PointCloud.from_points_in_array(points_in_array, PC1.pose)

    def transform(self, transform: Transform):
        points_list = [point.transform(transform)for point in self.points]
        return PointCloud(points_list, self.pose)

    def represent_in_other_pose_frame(self, other_pose: Pose):

        frame_change_transform = other_pose.value.inverse_transpose(
        ).concatenate(self.pose.value)
        points_list: List[Vector] = [point.transform(
            frame_change_transform) for point in self.points]
        return PointCloud(points_list, other_pose)

    def change_frame(self, down_chain: List[Pose], up_chain: List[Pose]):
        frame_change_transform = Transform.get_frame_change_transform(
            down_chain, up_chain)
        PC_transformed = self.transform(frame_change_transform)
        # set the pose to the target pose
        if len(up_chain) == 0:
            PC_transformed.pose = down_chain.pop()
        else:
            PC_transformed.pose = up_chain.pop()
        return PC_transformed

    def size(self):
        return len(self.points)

    def get_points_as_array(self):
        return np.array(self.points)

    def get_x_values(self):
        return self.in_array()[:, 0]

    def get_y_values(self):
        return self.in_array()[:, 1]

    def get_z_values(self):
        return self.in_array()[:, 2]

    def in_array(self):
        array_format = [vector.xyz_in_array() for vector in self.points]
        return np.array(array_format)

    def drop_repetitive_points(self):
        return PointCloud.unique_merge(self, self)

    def sort_points(self, xyz=[2, 1, 0], ascending=[True, True, True]):
        a = self.in_array()
        return PointCloud.from_points_in_array(a[np.lexsort((ascending * a[:, xyz]).T)],
                                               copy.deepcopy(self.pose))

    def compare(self, other, precision=default_precision):
        if isinstance(other, PointCloud):
            self.pose.compare(other.pose, precision)
            a = self.drop_repetitive_points().sort_points()
            b = other.drop_repetitive_points().sort_points()
            # TODO: This compare function is nothing but comparing to lists of vectors.
            # Potential code overlap with
            #  other parts shall be addressed.
            if a.size() == b.size():
                for index in range(0, len(a.points)):
                    a.points[index].compare(b.points[index], precision)
            else:
                raise Exception("The lengths are not of the same size.")


class Topography:
    X: np.ndarray
    Y: np.ndarray
    Z: np.ndarray

    def __init__(self, X: np.ndarray, Y: np.ndarray, Z: np.ndarray):
        self.X = X
        self.Y = Y
        self.Z = Z


class Mesh:
    vertices: List[Vector]
    triangle_indices: List[List[int]]
    pose: Pose
    mesh_indices_for_area2d_points: List[int]

    def __init__(self, vertices: List[Vector], triangle_indices: List[List[int]], pose: Pose):
        self.vertices = vertices
        self.triangle_indices = triangle_indices
        self.pose = pose

    def set_mesh_indices_corresponds_to_projected_area2_points(self, mesh_indices_for_area2d_points: List[Vector]):
        self.mesh_indices_for_area2d_points = mesh_indices_for_area2d_points

    @classmethod
    def from_stl(cls):
        raise NotImplementedError

    def move(self, pose: Pose):
        self.pose = pose
        return self

    def transform(self, transform: Transform):
        # transforms the mesh vertices with the given transform
        vertices = [vertex.transform(transform) for vertex in self.vertices]
        return Mesh(vertices, self.triangle_indices, self.pose)

    def change_frame(self, down_chain: List[Pose], up_chain: List[Pose]):
        frame_change_transform = Transform.get_frame_change_transform(
            down_chain, up_chain)
        mesh_transformed = self.transform(frame_change_transform)
        # set the pose to the target pose
        if len(up_chain) == 0:
            mesh_transformed.pose = down_chain.pop()
        else:
            mesh_transformed.pose = up_chain.pop()
        return mesh_transformed

    # TODO: a method should be added to convert MESH to stl-Mesh

    def compare(self, other, precision):

        if isinstance(other, Mesh):
            self.pose.compare(other.pose, precision)

            number_of_same_vertices = 0
            if len(self.vertices) == len(other.vertices):
                for index in range(0, len(self.vertices)):
                    for index_j in range(0, len(other.vertices)):
                        try:
                            self.vertices[index].compare(
                                other.vertices[index_j], precision)
                        except Exception:
                            continue
                        else:
                            number_of_same_vertices += 1

                if number_of_same_vertices == len(self.vertices):
                    pass
                else:
                    raise Exception("These 2 mesh are not equal")
            else:
                raise Exception('not the same number of vertices')

            number_of_same_triangles = 0
            # TODO: Change compare method to use connectivity matrix and index transform
            # then remove Triangle class
            if len(self.triangle_indices) == len(other.triangle_indices):
                for index in self.triangle_indices:
                    for index_j in other.triangle_indices:
                        triangle_1 = Triangle(self.vertices[index[0]], self.vertices[
                            index[1]], self.vertices[index[2]])
                        triangle_2 = Triangle(other.vertices[index_j[0]], other.vertices[
                            index_j[1]], other.vertices[index_j[2]])
                        try:
                            triangle_1.compare(triangle_2, precision)
                        except Exception:
                            continue
                        else:
                            number_of_same_triangles += 1

                if number_of_same_triangles == len(self.triangle_indices):
                    pass
                else:
                    raise Exception("These 2 mesh are not equal")
            else:
                raise Exception('not the same number of triangles')

        else:
            raise InputAreNotTheSameDataType

    def get_bounding_sphere(self) -> Sphere:
        center = Vector.origin()

        for vertex in self.vertices:
            center.add(vertex)
        center = center.scale(1.0/float(len(self.vertices)))

        # get maximal distance to the vertices from mean_point
        distances = [center.subtract(vertex).norm()
                     for vertex in self.vertices]
        radius = max(distances)

        return Sphere(center, radius)

    def to_flatmanifold(self, precision) -> FlatManifold:
        """"Convert the Mesh into flatmanifold and remove the triangles
        that only defines a line or a point"""
        # TODO: pygeos showed that this method does't remove all overlapping triangles. Check if we need to take care of this or not
        # Labels: enhancement
        flatManifold = FlatManifold(self.to_area2D(precision), self.pose)
        return flatManifold

    def to_area2D(self, precision) -> Area2D:
        """"Convert the Mesh into Area2D and remove the triangles
        that only defines a line or a point"""
        # ignores y-values!!
        # 5. Calculate the union of all triangles
        polygons = []
        for triangle in self.triangle_indices:
            # if any of two of vertex are at the same point in x_z plane, then this triangle is
            # discarded.
            condition_1 = np.sqrt(np.square(self.vertices[triangle[0]].x() - self.vertices[triangle[1]].x()) +
                                  np.square(self.vertices[triangle[0]].z() - self.vertices[triangle[1]].z())) \
                < precision

            condition_2 = np.sqrt(np.square(self.vertices[triangle[0]].x() - self.vertices[triangle[2]].x()) +
                                  np.square(self.vertices[triangle[0]].z() - self.vertices[triangle[2]].z())) \
                < precision

            condition_3 = np.sqrt(np.square(self.vertices[triangle[1]].x() - self.vertices[triangle[2]].x()) +
                                  np.square(self.vertices[triangle[1]].z() - self.vertices[triangle[2]].z())) \
                < precision

            # After the projection, it Triangle becomes a line, it also need to be neglected
            # The cases where x_values or z_values are all the same.
            condition_4 = self.vertices[triangle[0]].x(
            ) == self.vertices[triangle[1]].x() == self.vertices[triangle[2]].x()

            condition_5 = self.vertices[triangle[0]].z(
            ) == self.vertices[triangle[1]].z() == self.vertices[triangle[2]].z()

            if condition_1 or condition_2 or condition_3 or condition_4 or condition_5:
                continue

            tuple_pair = [(self.vertices[triangle[0]].x(), self.vertices[triangle[0]].z()),
                          (self.vertices[triangle[1]].x(),
                           self.vertices[triangle[1]].z()),
                          (self.vertices[triangle[2]].x(), self.vertices[triangle[2]].z())]

            polygons.append(pygeos.polygons(tuple_pair))

        try:
            area = pygeos.constructive.simplify(
                pygeos.set_operations.union_all(polygons), tolerance=wp_slice_precision)

            # Remove polygon points which have not descended from mesh vertices
            area_points_corresponding_to_mesh_points = []
            for point in pygeos.get_coordinates(area):
                for vertex in self.vertices:
                    if point[0] == vertex.x() and point[1] == vertex.z():
                        area_points_corresponding_to_mesh_points.append(point)
                        break
            area2d = Area2D.from_pygeos_polygon(pygeos.polygons(
                area_points_corresponding_to_mesh_points))
        except pygeos.GEOSException:
            print(
                'pygeos.GEOSException is encountered, retrying union_all with 1E-3 grid size.')
            area = pygeos.constructive.simplify(
                pygeos.set_operations.union_all(polygons, grid_size=1E-3), tolerance=wp_slice_precision)

            # Remove polygon points which have not descended from mesh vertices
            area_points_corresponding_to_mesh_points = []
            for point in pygeos.get_coordinates(area):
                for vertex in self.vertices:
                    if point[0] == np.round(vertex.x(), 3) and point[1] == np.round(vertex.z(), 3):
                        area_points_corresponding_to_mesh_points.append(point)
                        break
            area2d = Area2D.from_pygeos_polygon(pygeos.polygons(
                area_points_corresponding_to_mesh_points))
        except RuntimeWarning:
            print(polygons)
            raise Exception('A RuntimeWarning is generated here.')
        else:
            pass

        return area2d

    def to_stl_mesh(self):
        mesh_stl = stl.mesh.Mesh(
            np.zeros(len(self.triangle_indices), dtype=stl.mesh.Mesh.dtype))
        for i, f in enumerate(self.triangle_indices):
            for j in range(3):
                vector = self.vertices[f[j]]
                mesh_stl.vectors[i][j] = vector.value[:3]

        return mesh_stl

    def get_geometric_properties(self) -> Tuple[float, float, np.array]:
        """ Return volume, center of gravity and inertia matrix of the mesh """
        volume, cog, inertia = self.to_stl_mesh().get_mass_properties()

        return volume, cog, inertia


def to_area2D_old(self, precision) -> Area2D:
    """"Convert the Mesh into Area2D and remove the triangles
    that only defines a line or a point"""
    # ignores y-values!!
    # 5. Calculate the union of all triangles
    union_area = Area2D.empty()
    debug_index = 0
    for triangle in self.triangles:
        # if any of two of vertex are at the same point in x_z plane, then this triangle is
        # discarded.
        condition_1 = np.sqrt(np.square(triangle.vertex_1.x() - triangle.vertex_2.x()) +
                              np.square(triangle.vertex_1.z() - triangle.vertex_2.z())) \
            < precision

        condition_2 = np.sqrt(np.square(triangle.vertex_1.x() - triangle.vertex_3.x()) +
                              np.square(triangle.vertex_1.z() - triangle.vertex_3.z())) \
            < precision

        condition_3 = np.sqrt(np.square(triangle.vertex_2.x() - triangle.vertex_3.x()) +
                              np.square(triangle.vertex_2.z() - triangle.vertex_3.z())) \
            < precision

        # After the projection, it Triangle becomes a line, it also need to be neglected
        # The cases where x_values or z_values are all the same.
        condition_4 = triangle.vertex_1.x() == triangle.vertex_2.x() == triangle.vertex_3.x()

        condition_5 = triangle.vertex_1.z() == triangle.vertex_2.z() == triangle.vertex_3.z()

        if condition_1 or condition_2 or condition_3 or condition_4 or condition_5:
            continue

        x_values = np.array(
            [triangle.vertex_1.x(), triangle.vertex_2.x(), triangle.vertex_3.x()])
        z_values = np.array(
            [triangle.vertex_1.z(), triangle.vertex_2.z(), triangle.vertex_3.z()])
        union_area = union_area.union(
            Area2D.from_np_arrays(x_values, z_values))
        debug_index += 1
    return union_area


class RectangleManifold:
    """RectangleManifold is defined by four points in the x_z plane and a pose in 3D coordinate.
    It's used as a bounding rectangle for FlatManifold.
    The pose of RectangleManifold is based on Workpiece frame.
    """
    pose: Pose
    x_min: float
    x_max: float
    z_min: float
    z_max: float

    def __init__(self, x_min: float, x_max: float, z_min: float, z_max: float, pose: Pose):
        self.pose = pose
        self.x_min = x_min
        self.x_max = x_max
        self.z_min = z_min
        self.z_max = z_max

    @ classmethod
    def from_Area2D_and_pose(cls, area: Area2D, pose: Pose):

        boundary = area.to_line2d()
        x_min = min(boundary.x_values)
        x_max = max(boundary.x_values)

        z_min = min(boundary.z_values)
        z_max = max(boundary.z_values)

        return cls(x_min, x_max, z_min, z_max, pose)

    def move(self, pose: Pose):
        return RectangleManifold(self.x_min, self.x_max, self.z_min, self.z_max,
                                 copy.deepcopy(pose))

    def get_proximity(self, point: Vector,
                      proximity_distance: float) -> FlatManifoldProximityResult:

        # transform the point into the pose-coordinate system and check proximity
        p_transformed = point.change_frame_point([], [self.pose])
        is_inside = False
        is_front = False
        is_back = False
        is_close = False
        distance = p_transformed.y()
        if np.abs(distance) < proximity_distance:
            is_close = True

        if distance > 0:
            is_front = True
        else:
            is_back = True

        if np.abs(distance < proximity_distance
                  and p_transformed.x() >= self.x_min-proximity_distance
                  and p_transformed.x() <= self.x_max+proximity_distance
                  and p_transformed.z() >= self.z_min-proximity_distance
                  and p_transformed.z() <= self.z_max+proximity_distance
                  and is_close
                  ):
            is_inside = True

        return FlatManifoldProximityResult(is_inside,
                                           is_front, is_back)

    def get_points_proximities(self, points_in_fm_frame: List[Vector],
                               proximity_distances: List[float]) -> List[FlatManifoldProximityResult]:

        # transform the point into the pose-coordinate system and check proximity
        # points_transformed = Vector.change_frame_point_list(points, [], [
        #                                                     self.pose])

        points_transformed = points_in_fm_frame
        list_of_fm_proximity_result = []
        for point_index, p_transformed in enumerate(points_transformed):
            is_inside = False
            is_front = False
            is_back = False
            is_close = False
            distance = p_transformed.y()
            if np.abs(distance) < proximity_distances[point_index]:
                is_close = True

            if distance > 0:
                is_front = True
            else:
                is_back = True

            if np.abs(distance < proximity_distances[point_index]
                      and p_transformed.x() >= self.x_min-proximity_distances[point_index]
                      and p_transformed.x() <= self.x_max+proximity_distances[point_index]
                      and p_transformed.z() >= self.z_min-proximity_distances[point_index]
                      and p_transformed.z() <= self.z_max+proximity_distances[point_index]
                      and is_close
                      ):
                is_inside = True

            list_of_fm_proximity_result.append(FlatManifoldProximityResult(is_inside,
                                               is_front, is_back))

        return list_of_fm_proximity_result

    def compare(self, other, precision):
        if isinstance(other, RectangleManifold):
            self.pose.compare(other.pose, precision)
            compare_np_arrays(self.x_min, other.x_min, precision)
            compare_np_arrays(self.x_max, other.x_max, precision)
            compare_np_arrays(self.z_min, other.z_min, precision)
            compare_np_arrays(self.z_max, other.z_max, precision)

        else:
            raise InputAreNotTheSameDataType


class FlatManifold:
    """a FlatManifold is 2D-Area embedded in 3D Space
    The embedding is done by identifying the 2D x-coordinates
    with the 3D x-coordinates and the 2D-y-coordinates with the 3D z-coordinates
    the position and orientation is then specified by a pose.
    """

    pose: Pose
    area: Area2D
    points_proximities: Callable[[List[Vector],
                                  List[float]], List[FlatManifoldProximityResult]]
    __registered_area: Area2D

    def __init__(self, area: Area2D, pose: Pose):
        self.area = area
        self.pose = pose

        bounding_rectangle = RectangleManifold.from_Area2D_and_pose(area, pose)
        self.points_proximities = bounding_rectangle.get_points_proximities
        self.__registered_area = Area2D.empty()

    @property
    def registered_area(self):
        return self.__registered_area

    def register_area(self, area_to_register: RegisteredAreaOnPlane):
        self.__registered_area = area_to_register.area

    @ classmethod
    def from_two_diagonal_points(cls, lowerLeft: Vector,
                                 upperRight: Vector, pose: Pose):
        if lowerLeft.y() == upperRight.y() == 0:
            # create polygon from input variables
            # input the 4 points of x-z value pair to construct polygon
            line = Line2D(np.array([lowerLeft.x(), lowerLeft.x(), upperRight.x(), upperRight.x()]),
                          np.array([lowerLeft.z(), upperRight.z(), upperRight.z(), lowerLeft.z()]))
            area = Area2D(line)
            pose = pose
            return cls(area, pose)
        else:
            raise Exception(" lowerLeft.y() !=0 & upperRight.value.y() != 0")

    @ classmethod
    def from_boundary_points_on_x_z_plane(cls, points: List[Vector], pose: Pose):
        """Construct a flatmanifold from points on x_z plane"""
        # TODO: Maybe this method can take 3D points and calculate the pose of the flatmanifold from the points.

        Vector.check_coplanarity(points)

        the_normal_vector_of_points_list = points[0].subtract(
            points[1]).cross(points[1].subtract(points[2]))

        if the_normal_vector_of_points_list.dot(Vector.e_z()) - 0 > default_precision:
            raise Exception(
                "There are boundary points not on the plane that is perpendicular to x_y plane")

        x_value = np.array([V.x() for V in points])
        z_value = np.array([V.z() for V in points])
        return cls.from_x_z_arrays(x_value, z_value, pose)

    @ classmethod
    def from_x_z_arrays(cls, x_points: np.ndarray,
                        z_points: np.ndarray, pose: Pose):
        if len(x_points) == len(z_points):
            area = Area2D(Line2D(x_points, z_points))
            pose = pose
            return cls(area, pose)
        else:
            raise Exception(
                "The length of x array and z array should be the same.")

    @ classmethod
    def from_profile(cls, line: Line2D, pose: Pose):
        area = Area2D(line)
        pose = pose
        return cls(area, pose)

    def get_boundary_points_in_base_frame(self) -> List[Vector]:
        # returns the points on the manifold represented in the base frame of the manifold
        boundary_points: List[Vector] = self.area.get_boundary_points()
        # transform boundary points
        boundary_points_in_base = Vector.change_frame_point_list(
            boundary_points, [self.pose], [])
        return boundary_points_in_base

    def get_normal(self) -> Vector:
        return Vector.e_y()

    def project_mesh_onto(self, mesh: Mesh, projection_direction: Vector) -> Mesh:
        '''Project mesh in plane frame onto the plane. Input mesh should be represented in manifold(slice) frame'''
        # 2. Project triangles x-z plane in manifold frame
        projection = Transform.from_projection_along_vector_to_x_z_plane(
            projection_direction)
        projected_mesh = mesh.transform(projection)

        return projected_mesh

    def change_frame(self, down_chain: List[Pose], up_chain: List[Pose]):
        '''This method is used to change the frame of FM in ReducedGrain'''
        frame_change_transform = Transform.get_frame_change_transform(
            down_chain, up_chain)
        vector_list = self.get_boundary_points_in_base_frame()
        vector_list_on_fm_frame = Vector.transform_list(
            vector_list, self.pose.value.inverse())
        transformed_vectors = Vector.transform_list(
            vector_list, frame_change_transform)

        transformed_pose = self.pose.transform(frame_change_transform)
        # tf_vectors_on_tf_pose = Vector.transform_list(
        #     transformed_vectors, transformed_pose.value.inverse())

        # fm_transformed = self.transform(frame_change_transform)
        fm_transformed = FlatManifold.from_boundary_points_on_x_z_plane(
            transformed_vectors, transformed_pose)
        # set the pose to the target pose
        # if len(up_chain) == 0:
        #     fm_transformed.pose = down_chain.pop()
        # else:
        #     fm_transformed.pose = up_chain.pop()
        return fm_transformed

    def project_flatmanifold_points_onto(self, flatmanifold_points: List[Vector], projection_direction: Vector) -> Area2D:
        '''Project a 2D flatmanifold to another plane and generate a Area2D. The input manifold should be in plane frame.'''
        # fm = FlatManifold.from_boundary_points_on_x_z_plane(
        #     flatmanifold_points)

        projection = Transform.from_projection_along_vector_to_x_z_plane(
            projection_direction)
        transformed_vectors = Vector.transform_list(
            flatmanifold_points, projection)
        # projected_pose = flatmanifold.pose.transform(projection)
        projected_area = FlatManifold.from_boundary_points_on_x_z_plane(
            transformed_vectors, self.pose).area

        # projected_area_pygeos = pygeos.coordinates.apply(
        #     fm.area, lambda x: np.matmul(x, projection))

        return projected_area

    def project_point_onto(self, point: Vector, projection_direction: Vector) -> Vector:
        projection = Transform.from_projection_along_vector_to_x_z_plane(
            projection_direction)
        projected_point = point.transform(projection)
        return projected_point

    def update_bounding_rectangle(self):
        bounding_rectangle = RectangleManifold.from_Area2D_and_pose(
            self.area, self.pose)
        self.points_proximities = bounding_rectangle.get_proximity

        raise NotImplementedError

    def compare(self, other, precision):
        """Compares the manifold to another"""
        if isinstance(other, FlatManifold):
            self.pose.compare(other.pose, precision)
            self.area.compare(other.area, precision)
        else:
            raise InputAreNotTheSameDataType

    def save_to_disk(self, file_name: str):
        with open(file_name, 'wb') as file:
            dill.dump(self, file)

    @staticmethod
    def load_from_disk(file_name):
        with open(file_name, 'rb') as file:
            fm = dill.load(file)
        if isinstance(fm, FlatManifold):
            return fm
        else:
            Exception(
                "The loaded FlatManifold object is not from the current version of this class.")


class Box:
    """Box is defined by 6 points in 3D coordinate, a pose, and a proximity function that is passed
    through input. Box is created to serve as a bounding box for Workpiece.
    The proximity function is used to detect grain's proximity to the workpiece.
    """

    # define properties of box
    pose: Pose
    bounding_sphere: Sphere
    x_min: float
    x_max: float
    y_min: float
    y_max: float
    z_min: float
    z_max: float

    def __init__(self, x_min: float, x_max: float,
                 y_min: float, y_max: float,
                 z_min: float, z_max: float,
                 pose: Pose):

        if (x_max - x_min) < 0:
            raise Exception('x_max should be higher x_min')
        if (y_max - y_min) < 0:
            raise Exception('y_max should be higher y_min')
        if (z_max - z_min) < 0:
            raise Exception('z_max should be higher z_min')

        self.pose = pose
        self.x_min = x_min
        self.x_max = x_max
        self.y_min = y_min
        self.y_max = y_max
        self.z_min = z_min
        self.z_max = z_max

    @ classmethod
    def as_bounding_box_of_points(cls, points: List[Vector], pose=Pose.identity()):

        slice_points_x = []
        slice_points_y = []
        slice_points_z = []

        for k in range(0, len(points)):
            slice_points_x.append(points[k].x())
            slice_points_y.append(points[k].y())
            slice_points_z.append(points[k].z())

        x_min = min(slice_points_x)
        x_max = max(slice_points_x)

        y_min = min(slice_points_y)
        y_max = max(slice_points_y)

        z_min = min(slice_points_z)
        z_max = max(slice_points_z)

        return cls(x_min, x_max, y_min, y_max, z_min, z_max,
                   pose)

    def get_distance_to_points(self, points_in_wp_frame: List[Vector]) -> List[float]:
        points_transformed = points_in_wp_frame
        distance_list = []
        for point in points_transformed:
            d_x_low_plane = self.x_min-point.x()
            d_x_high_plane = point.x()-self.x_max

            d_y_low_plane = self.y_min-point.y()
            d_y_high_plane = point.y()-self.y_max

            d_z_low_plane = self.z_min-point.z()
            d_z_high_plane = point.z()-self.z_max

            distances = [d_x_low_plane, d_x_high_plane,
                         d_y_low_plane, d_y_high_plane,
                         d_z_low_plane, d_z_high_plane]

            negative_distances = [*filter(lambda x: x <= 0, distances)]
            positive_distances = [*filter(lambda x: x > 0, distances)]

            # check if all elements are negative --> point inside
            if len(negative_distances) == len(distances):
                distance = max(negative_distances)
            else:
                distance = max(positive_distances)

            distance_list.append(distance)

        return distance_list

    @property
    def bounding_sphere(self) -> Sphere:
        radius = np.sqrt((self.x_max - self.x_min)**2 + (self.y_max -
                         self.y_min)**2 + (self.z_max - self.z_min)**2)/2
        center = Vector((self.x_max - self.x_min)/2,
                        (self.y_max - self.y_min)/2, (self.z_max - self.z_min)/2)
        return Sphere(center, radius)

    def get_distance_to_single_point(self, point_in_wp_frame: List[Vector]) -> List[float]:
        points_transformed = point_in_wp_frame

        d_x_low_plane = self.x_min-points_transformed[0].x()
        d_x_high_plane = points_transformed[0].x()-self.x_max

        d_y_low_plane = self.y_min-points_transformed[0].y()
        d_y_high_plane = points_transformed[0].y()-self.y_max

        d_z_low_plane = self.z_min-points_transformed[0].z()
        d_z_high_plane = points_transformed[0].z()-self.z_max

        distances = [d_x_low_plane, d_x_high_plane,
                     d_y_low_plane, d_y_high_plane,
                     d_z_low_plane, d_z_high_plane]

        negative_distances = [*filter(lambda x: x <= 0, distances)]
        positive_distances = [*filter(lambda x: x > 0, distances)]

        # check if all elements are negative --> point inside
        if len(negative_distances) == len(distances):
            distance = max(negative_distances)
        else:
            distance = max(positive_distances)

        return distance

    def proximity(self, point: Vector, proximity_distance: float) -> VolumeProximityResult:
        is_in_proximity = False

        result = self.get_distance_to_single_point([point])

        if result <= 0:
            is_in_proximity = True
        elif proximity_distance > result:
            is_in_proximity = True
        else:
            is_in_proximity = False

        return VolumeProximityResult(is_in_proximity)

    @ classmethod
    def from_sizes(cls, size_x: float, size_y: float, size_z: float, pose: Pose):
        return cls(0, size_x, 0, size_y, 0, size_z, pose)

    def compare(self, other, precision):
        if isinstance(other,  Box):
            self.pose.compare(other.pose, precision)
            compare_np_arrays(self.x_min, other.x_min, precision)
            compare_np_arrays(self.x_max, other.x_max, precision)
            compare_np_arrays(self.y_min, other.y_min, precision)
            compare_np_arrays(self.y_max, other.y_max, precision)
            compare_np_arrays(self.z_min, other.z_min, precision)
            compare_np_arrays(self.z_max, other.z_max, precision)

        else:
            raise InputAreNotTheSameDataType


class Cylinder:
    """A Cylinder is created with pose, radius in x_y plane,
    height in z axis and proximity callable that
    is passed through input. A cylinder is currently
    used as basic geometry to generate cylinder shape
    workpiece.
    """

    # define properties of cylinder
    pose: Pose
    radius: float
    z_min: float
    z_max: float

    def __init__(self, radius: float, z_min: float, z_max: float, pose: Pose):
        self.pose = pose

        if radius < 0:
            raise Exception('Radius should be positive')
        if (z_max - z_min) < 0:
            raise Exception('z_max should be higher than z_min')

        self.radius = radius
        self.z_min = z_min
        self.z_max = z_max

    def get_distance_to_points(self, points_in_wp_frame: List[Vector]) -> List[float]:
        points_transformed = points_in_wp_frame
        distance_list = []
        for p_transformed in points_transformed:
            distance = np.sqrt(p_transformed.x()**2 + p_transformed.y()**2)

            d_z_low_plane = self.z_min-p_transformed.z()
            d_z_high_plane = p_transformed.z()-self.z_max
            d_radial = distance - self.radius

            distances = [d_z_low_plane, d_z_high_plane, d_radial]

            negative_distances = [*filter(lambda x: x <= 0, distances)]
            positive_distances = [*filter(lambda x: x > 0, distances)]

            # check if all elements are negative --> point inside
            if len(negative_distances) == len(distances):
                distance = max(negative_distances)
            else:
                distance = max(positive_distances)

            distance_list.append(distance)
        return distance_list

    def get_distance_to_single_point(self, point_in_wp_frame: Vector) -> float:
        p_transformed = point_in_wp_frame

        distance = np.sqrt(p_transformed.x()**2 + p_transformed.y()**2)

        d_z_low_plane = self.z_min-p_transformed.z()
        d_z_high_plane = p_transformed.z()-self.z_max
        d_radial = distance - self.radius

        distances = [d_z_low_plane, d_z_high_plane, d_radial]

        negative_distances = [*filter(lambda x: x <= 0, distances)]
        positive_distances = [*filter(lambda x: x > 0, distances)]

        # check if all elements are negative --> point inside
        if len(negative_distances) == len(distances):
            distance = max(negative_distances)
        else:
            distance = max(positive_distances)

        return distance

    def proximity(self, point: Vector, proximity_distance: float) \
            -> VolumeProximityResult:
        is_in_proximity = False

        distance = self.get_distance_to_single_point(point)

        if distance <= 0:
            is_in_proximity = True
        elif proximity_distance > distance:
            is_in_proximity = True
        else:
            is_in_proximity = False

        return VolumeProximityResult(is_in_proximity)

    def compare(self, other, precision):
        if isinstance(other,  Cylinder):
            self.pose.compare(other.pose, precision)
            compare_np_arrays(self.radius, other.radius, precision)
            compare_np_arrays(self.z_min, other.z_min, precision)
            compare_np_arrays(self.z_max, other.z_max, precision)
        else:
            raise InputAreNotTheSameDataType


class ExtrudedVolume:
    """The ExtrudedVolume is generated by a pose, a FlatManifold front face used for extrusion,
    length of extrusion and proximity
    callable passed through input. The ExtrudedVolume provides possiblily
    to generate workpiece from extruded volume.
    """
    # define properties of ExtrudedVolume
    pose: Pose
    front_face: FlatManifold
    extrusion_length_y: float

    def __init__(self, front_face: FlatManifold, extrusion_length: float):
        self.pose = front_face.pose
        if extrusion_length < 0:
            raise Exception('Extrusion length should be positive')

        self.front_face = front_face
        self.extrusion_length = extrusion_length

    def get_distance_to_points(self, points_in_wp_frame: List[Vector]) -> List[float]:
        front_face_boundary = self.front_face.area.to_line2d()

        x_min = min(front_face_boundary.x_values)
        x_max = max(front_face_boundary.x_values)
        z_min = min(front_face_boundary.z_values)
        z_max = max(front_face_boundary.z_values)

        bounding_box = Box(
            x_min, x_max, 0, self.extrusion_length, z_min, z_max, self.pose)
        box_distances = bounding_box.get_distance_to_points(points_in_wp_frame)
        return box_distances

    def get_distance_to_single_point(self, point_in_wp_frame: Vector) -> float:
        front_face_boundary = self.front_face.area.to_line2d()

        x_min = min(front_face_boundary.x_values)
        x_max = max(front_face_boundary.x_values)
        z_min = min(front_face_boundary.z_values)
        z_max = max(front_face_boundary.z_values)

        bounding_box = Box(
            x_min, x_max, 0, self.extrusion_length, z_min, z_max, self.pose)
        box_distance = bounding_box.get_distance_to_single_point(
            point_in_wp_frame)
        return box_distance

    def proximity(self, point: Vector, proximity_distance: float) \
            -> VolumeProximityResult:
        is_in_proximity = False

        distance = self.get_distance_to_single_point([point])

        if distance <= 0:
            is_in_proximity = True
        elif proximity_distance > distance:
            is_in_proximity = True
        else:
            is_in_proximity = False

        return VolumeProximityResult(is_in_proximity)

    def move(self, pose: Pose):
        new_ExtrudedVolume = copy.deepcopy(self)
        new_ExtrudedVolume.pose = copy.deepcopy(pose)
        return new_ExtrudedVolume

    def compare(self, other, precision):
        if isinstance(other,  ExtrudedVolume):
            self.pose.compare(other.pose, precision)
            self.front_face.compare(other.front_face, precision)
            compare_np_arrays(self.extrusion_length,
                              other.extrusion_length, precision)
        else:
            raise InputAreNotTheSameDataType
