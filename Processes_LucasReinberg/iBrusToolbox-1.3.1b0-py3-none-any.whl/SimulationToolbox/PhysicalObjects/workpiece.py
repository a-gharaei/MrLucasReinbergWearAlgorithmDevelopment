"""This files hold ths workpiece factory."""

from SimulationToolbox.Geometry.geometry import *
from SimulationToolbox.Geometry.geometric_objects import *
from typing import *
from typing import Mapping, Callable
import copy
import dill
from scipy.interpolate import griddata as gd


class Workpiece:
    '''This class holds the basic geometry of workpiece prototype.
    It provides method to generate workpiece prototype with
    a defined method/logic.
    '''
    # we do not have a pose of workpiece, moving needs to be done with pose of slices
    distance_to_points: Callable[[List[Vector]], List[float]]
    single_point_distance: Callable[[List[Vector]], List[float]]
    slices: List[FlatManifold]
    pose: Pose

    def __init__(self, slices: List[FlatManifold],
                 pose: Pose, distance_to_points: Callable[[List[Vector]], List[float]] = None,
                 single_point_distance: Callable[[List[Vector]], List[float]] = None):

        if distance_to_points is not None:
            self.slices = copy.deepcopy(slices)
            self.distance_to_points = copy.deepcopy(distance_to_points)
            self.single_point_distance = copy.deepcopy(
                single_point_distance)
            self.pose = copy.deepcopy(pose)
        else:
            # calculate a boundingbox proximity callable
            # the bounding box has pose: mean_pose_of_slices

            # TODO Workpiece.init move part of the code to box and flat manifold
            # in Box:  -> box.from_flat_manifolds_as_bounding_box
            # in FlatManifold -> get extramalpoints
            slice_points: List[Vector] = []
            for slice in slices:
                slice_points.extend(slice.get_boundary_points_in_base_frame())

            # transform all points into the workpiece frame
            new_slice_points = [point.change_frame_point(
                [], [pose]) for point in slice_points]

            slice_points_x = []
            slice_points_y = []
            slice_points_z = []

            for k in range(0, len(new_slice_points)):
                slice_points_x.append(new_slice_points[k].x())
                slice_points_y.append(new_slice_points[k].y())
                slice_points_z.append(new_slice_points[k].z())

            x_min = min(slice_points_x)
            x_max = max(slice_points_x)

            y_min = min(slice_points_y)
            y_max = max(slice_points_y)

            z_min = min(slice_points_z)
            z_max = max(slice_points_z)

            box = Box.as_bounding_box_of_points(new_slice_points, pose)

            self.slices = copy.deepcopy(slices)
            self.distance_to_points = box.get_distance_to_points
            self.single_point_distance = box.get_distance_to_single_point
            self.pose = copy.deepcopy(pose)

    # def proximity(self, point: Vector, proximity_distance: float) -> VolumeProximityResult:
    #     is_in_proximity = False
    #     distance = self.single_point_proximity(point)

    #     if distance <= 0:
    #         is_in_proximity = True
    #     elif proximity_distance > distance:
    #         is_in_proximity = True
    #     else:
    #         is_in_proximity = False
    #     return VolumeProximityResult(is_in_proximity)

    @ classmethod
    def from_box(cls, box: Box, spatial_resolution):
        # the slicing is done along vertical planes parallel to the x-axis-of the box

        if spatial_resolution <= 0:
            raise Exception(
                "Spatial resolution should be greater than zero")

        if spatial_resolution > (box.y_max-box.y_min):
            raise Exception(
                "Spatial resolution should not be greater than box length")

        slices: List[FlatManifold] = []

        translation_to_first_slice = Vector.origin().add(
            Vector.e_y().scale(box.y_min))
        current_slice_origin = translation_to_first_slice

        current_slice_pose = Pose(
            Transform.from_translation(current_slice_origin))

        shift_to_next_slice = Vector.e_y().scale(spatial_resolution)
        total_shift = 0

        while total_shift <= (box.y_max-box.y_min):

            lower_left = Vector(box.x_min, 0, box.z_min)
            upper_right = Vector(box.x_max, 0, box.z_max)

            slices.append(FlatManifold.from_two_diagonal_points(
                lower_left, upper_right, current_slice_pose))

            # calculate next slice pose
            current_slice_origin = current_slice_origin.add(
                shift_to_next_slice)
            current_slice_pose = Pose(
                Transform.from_translation(current_slice_origin))

            total_shift += spatial_resolution

        return cls(slices, box.pose, box.get_distance_to_points, box.get_distance_to_single_point)

    @ classmethod
    def from_single_plane_box_offset(cls, plane: FlatManifold, y_offset: float, pose: Pose):
        plane_points = plane.get_boundary_points_in_base_frame()

        # transform all points into the mean_pose_of_slices frame
        for point in plane_points:
            point = point.change_frame_point([], [plane.pose])

        plane_points_x = []
        plane_points_y = []
        plane_points_z = []
        for k in range(0, len(plane_points)):
            plane_points_x.append(plane_points[k].x())
            plane_points_y.append(plane_points[k].y())
            plane_points_z.append(plane_points[k].z())

        x_min = min(plane_points_x)
        x_max = max(plane_points_x)

        y_min = min(plane_points_y)-y_offset
        y_max = max(plane_points_y)+y_offset

        z_min = min(plane_points_z)
        z_max = max(plane_points_z)

        box = Box(x_min, x_max, y_min, y_max, z_min, z_max,
                  pose)

        # TODO: as soon as code is stable move into tests
        for point in plane_points:
            proximity_result = box.proximity(point, 0)
            if not proximity_result.is_in_proximity:
                raise Exception("bounding box does not contain all points")
        return cls([plane], pose,  box.get_distance_to_points, box.get_distance_to_single_point)

    @ classmethod
    def from_cylinder(cls, cylinder: Cylinder, spatial_resolution):
        """Cylidner shape,the slicing is done with a star shaped plane organization"""

        if spatial_resolution <= 0:
            raise Exception(
                "Spatial resolution should be greater than zero")

        angular_resolution = spatial_resolution / cylinder.radius

        if angular_resolution > np.pi:
            raise Exception(
                'Spatial resolution should not be greater than half of cylinder circumferance')

        slices: List[FlatManifold] = []

        current_slice_pose = Pose.from_translation(Vector.origin())
        slice_angle = 0

        while slice_angle < np.pi:

            lower_left = Vector(-cylinder.radius, 0, cylinder.z_min)
            upper_right = Vector(cylinder.radius, 0, cylinder.z_max)

            slices.append(FlatManifold.from_two_diagonal_points(
                lower_left, upper_right, current_slice_pose))

            # calculate next slice pose
            slice_angle += angular_resolution
            current_slice_pose = Pose(Transform.from_axis_angle(
                Vector.e_z(), slice_angle).concatenate(
                    Pose.from_translation(Vector.origin()).value))

        return cls(slices, cylinder.pose, cylinder.get_distance_to_points, cylinder.get_distance_to_single_point)

    @ classmethod
    def from_extruded_volume(cls, extruded_volume: ExtrudedVolume, spatial_resolution):
        # the slicing is done along vertical planes parallel to the x-axis-of the volume

        if spatial_resolution <= 0:
            raise Exception(
                "Spatial resolution should be greater than zero")

        if spatial_resolution > extruded_volume.extrusion_length:
            raise Exception(
                "Spatial resolution should not be greater than extrusion length")

        slices: List[FlatManifold] = []

        current_slice_origin = Vector.origin()
        current_slice_pose = Pose(
            Transform.from_translation(current_slice_origin))

        shift_to_next_slice = Vector.e_y().scale(spatial_resolution)
        total_shift = 0

        while total_shift <= extruded_volume.extrusion_length:

            slices.append(FlatManifold(
                extruded_volume.front_face.area, current_slice_pose))

            # calculate next slice pose
            current_slice_origin = current_slice_origin.add(
                shift_to_next_slice)
            current_slice_pose = Pose(
                Transform.from_translation(current_slice_origin))

            total_shift += spatial_resolution

        return cls(slices, extruded_volume.pose, extruded_volume.get_distance_to_points, extruded_volume.get_distance_to_single_point)

    def to_pointcloud(self) -> PointCloud:
        return PointCloud(self.get_points_in_base(), copy.deepcopy(self.pose))

    def to_topography(self, resulution: float, slicing_height: float) -> Topography:
        pointcloud = self.to_pointcloud()

        # remove the points below the slicing height
        points_x = []
        points_y = []
        values = []
        for point in pointcloud.points:
            if point.z() >= slicing_height:
                values.append(point.value[2])
                points_x.append(point.value[0])
                points_y.append(point.value[1])

        points_x = np.asarray(points_x)
        points_y = np.asarray(points_y)
        values = np.asarray(values)
        x_min = np.min(points_x)
        y_min = np.min(points_y)
        x_max = np.max(points_x)
        y_max = np.max(points_y)
        # create gridded data

        x = np.arange(x_min, x_max, resulution)
        y = np.arange(y_min, y_max, resulution)
        X, Y = np.meshgrid(x, y)

        Z = gd((points_x, points_y), values, (X, Y), method='linear')
        return Topography(X, Y, Z)

    def update_bounding_box(self):
        bounding_box = Box.from_flat_manifolds_as_bounding_box(self.slices)

    def get_points_in_base(self):
        points: List[Vector] = []
        for slice in self.slices:
            flat_manifold_points_list = slice.get_boundary_points_in_base_frame()
            for flatmanifold_point in flat_manifold_points_list:
                points.append(
                    flatmanifold_point.change_frame_point([self.pose], []))
        return points

    def compare(self, other, precision):
        if isinstance(other, Workpiece):
            self.pose.compare(other.pose, precision)
            assert len(self.slices) == len(other.slices)
            slice_index = 0
            for slice in self.slices:
                slice.compare(other.slices[slice_index], precision)
                slice_index = slice_index+1
            # TODO compare callables is a general problem!
            # assert self.proximity.__code__.co_code == other.proximity.__code__.co_code

        else:
            raise InputAreNotTheSameDataType

    def save_to_disk(self, file_name: str):
        with open(file_name, 'wb') as file:
            dill.dump(self, file)

    @ staticmethod
    def load_from_disk(file_name):
        with open(file_name, 'rb') as file:
            wp = dill.load(file)
        if isinstance(wp, Workpiece):
            return wp
        else:
            Exception(
                "The loaded workpiece object is not from the current version of this class.")

    def get_area_size_difference_between_two_workpieces(self, other) -> List[float]:
        '''Return a list of float reprsenting the area size difference of each pair of plane when comparing 2 workpieces.'''
        if isinstance(other, Workpiece):
            if len(self.slices) == len(other.slices):
                difference_list = []
                for num in range(len(self.slices)):
                    try:
                        self.slices[num].pose.compare(
                            other.slices[num].pose, default_precision)
                    except Exception:
                        raise Exception(
                            f"Plane number {num} doesn't have the same pose in two workpiece.")
                    else:
                        # Area2D.remove_area() is not used here because when a smaller area tries to remove a bigger area, the result of it is 0 area, not negative area.
                        difference_list.append(
                            self.slices[num].area.size()-other.slices[num].area.size())
                return difference_list
            else:
                raise Exception(
                    "When comparing two workpiece, the number of planes should be the same")
        else:
            raise InputAreNotTheSameDataType

# TODO: wp.from_file
# TODO: from_box_and_surface_measurement(measurement, spatial_resolution, heighet...) method
# TODO: Workpiece: implement get_points_in_base_frame
