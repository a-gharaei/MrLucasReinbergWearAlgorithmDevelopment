from SimulationToolbox.Geometry.geometry import *  # pylint: disable=unused-wildcard-import
from SimulationToolbox.Geometry.geometric_objects import *  # pylint: disable=unused-wildcard-import
from typing import Callable
from typing import List, Tuple
import copy
import stl
import dill


class ReducedGrain:
    '''This class holds the grain displacement and grain mesh projected along displacement vector.'''
    projected_area: FlatManifold
    displacement_in_grain_frame: Vector
    projected_mesh_ancestor: Mesh
    mesh_indices_for_fm_points: List[Vector]

    def __init__(self, displacement_in_grain_frame: Vector, projected_mesh_ancestor: Mesh, projected_area: FlatManifold):
        self.displacement_in_grain_frame = displacement_in_grain_frame
        self.projected_area = projected_area
        self.projected_mesh_ancestor = projected_mesh_ancestor

    def set_mesh_indices_corresponds_to_projected_fm_points(self, mesh_indices_for_fm_points):
        self.mesh_indices_for_fm_points = mesh_indices_for_fm_points


class Grain:
    """This holds the grain class. As the basic unit for calculation, It should have the following
    attributes:
    pose: a 4x4 matrix to represent orientation and position
    orthogonal projected area: as 3x3 matrix
    material:
    representation: mesh/3D Polygon/ 2D Polygon
    """

    __mesh: Mesh
    pose: Pose
    center_protrusion: Vector
    bounding_sphere_radius: float
    # TODO refactor grain.bounding_sphere_radius --> sphere
    bounding_sphere: Sphere
    __reduced_grain: ReducedGrain
    pullout: bool

    def __init__(self, pose: Pose, mesh: Mesh, center_protrusion: Vector = Vector.origin()):
        # calculate_approximated_bounding_sphere
        # center=mean of vertices
        # radius such that all is included

        self.bounding_sphere = mesh.get_bounding_sphere()
        self.bounding_sphere_radius = self.bounding_sphere.radius
        self.__mesh = mesh

        if center_protrusion.norm != 0:
            self.pose = pose.transform(
                Transform.from_translation(center_protrusion))
        else:
            self.pose = pose

        self.center_protrusion = center_protrusion
        self.__reduced_grain = None
        self.pullout = False

    @property
    def reduced_grain(self):
        if self.__reduced_grain is None:
            raise Exception("Reduced Grain is not calculated.")
        else:
            return self.__reduced_grain

    def generate_reduced_grain(self, reduced_grain: ReducedGrain):
        self.__reduced_grain = reduced_grain
        return self

    @ classmethod
    def from_stl(cls, path: str, grain_pose: Pose, mesh_pose: Pose):
        stl_mesh = stl.mesh.Mesh.from_file(path)
        vertices = []
        triangle_indices = []
        for face in stl_mesh.vectors:
            vertices.extend((tuple(face[0]), tuple(face[1]), tuple(face[2])))
            triangle_indices.append(
                (tuple(face[0]), tuple(face[1]), tuple(face[2])))
        unique_vertices = list(set(vertices))
        new_indices = [[unique_vertices.index(triangle[i])
                        for i in range(3)] for triangle in triangle_indices]
        new_vertices = [Vector(vertex[0], vertex[1], vertex[2])
                        for vertex in unique_vertices]
        our_mesh = Mesh(new_vertices, new_indices, mesh_pose)
        return cls(grain_pose, our_mesh)

    @ classmethod
    def get_box_grain(cls, size: float, pose: Pose):
        s = size/2.0
        triangle_indices: List[tuple[int]] = []

        # Vertices
        vertex_1 = Vector(-s, -s, -s)
        vertex_2 = Vector(s, -s, -s)
        vertex_3 = Vector(s, s, -s)
        vertex_4 = Vector(-s, s, -s)
        vertex_5 = Vector(-s, -s, s)
        vertex_6 = Vector(s, -s, s)
        vertex_7 = Vector(s, s, s)
        vertex_8 = Vector(-s, s, s)
        vertices = [vertex_1, vertex_2, vertex_3, vertex_4,
                    vertex_5, vertex_6, vertex_7, vertex_8]

        # Triangles
        triangle_indices.append([0, 3, 1])
        triangle_indices.append([1, 3, 2])
        triangle_indices.append([0, 4, 7])
        triangle_indices.append([0, 7, 3])
        triangle_indices.append([4, 5, 6])
        triangle_indices.append([4, 6, 7])
        triangle_indices.append([5, 1, 2])
        triangle_indices.append([5, 2, 6])
        triangle_indices.append([2, 3, 6])
        triangle_indices.append([3, 7, 6])
        triangle_indices.append([0, 1, 5])
        triangle_indices.append([0, 5, 4])

        return cls(pose, Mesh(vertices, triangle_indices, Pose.identity()))

    def get_mesh(self):
        return self.__mesh

    def update_mesh(self, mesh):
        self.__mesh = mesh
        return self

    def update_mesh(self, mesh):
        self.__mesh = mesh
        return self

    def move(self, pose: Pose):
        # moves the manifold to the given pose
        grain_moved = copy.deepcopy(self)
        grain_moved.pose = copy.deepcopy(pose)
        return grain_moved

    def get_position(self) -> Vector:
        # gets the position of the grain represented in the frame where the grain is living in
        return self.pose.get_position()

    def get_position_in_base_frame(self, base_pose) -> Vector:
        position = self.pose.get_position()
        return position.change_frame_point([base_pose], [])

    def compare(self, other, precision):
        if isinstance(other, Grain):
            self.pose.compare(other.pose, precision)
            self.__mesh.compare(other.__mesh, precision)
            self.center_protrusion.compare(other.center_protrusion, precision)
        else:
            raise InputAreNotTheSameDataType

    def scale(self, scale: float):
        mesh = self.__mesh.transform(Transform.identity().scale(scale))
        pose = copy.deepcopy(self.pose)
        return Grain(pose, mesh)

    def save_to_disk(self, file_name: str):
        with open(file_name, 'wb') as file:
            dill.dump(self, file)

    @staticmethod
    def load_from_disk(file_name):
        with open(file_name, 'rb') as file:
            grain = dill.load(file)
        if isinstance(grain, Grain):
            return grain
        else:
            Exception(
                "The loaded grain object is not from the current version of this class.")

        # TODO: implement material
        # TODO: implement state
