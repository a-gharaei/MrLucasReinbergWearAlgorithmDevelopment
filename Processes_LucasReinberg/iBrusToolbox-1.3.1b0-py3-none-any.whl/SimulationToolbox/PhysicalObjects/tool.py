"""Tool factory
The idea of this tool factory is to provide different **Tool Prototype** based on geometry,
which enables users to generate their tool using the combination of the tool prototypes. This
prototype should ideally cover all the existing use cases and tools. For tools that can't be
generated from the prototype defined bellow, it will be further reviewed and added to the
core tool box module if necessary, by adapting the tool prototypes or other adjustment within
the spirit of the current design.
"""

from SimulationToolbox.Geometry.geometry import *
from SimulationToolbox.Geometry.geometric_objects import *
from SimulationToolbox.PhysicalObjects.grain import *
from typing import *
from typing import Callable
import copy
from numpy import random


def randomly_sample_grain_pose(inner_radius: float, outer_radius: float):
    '''Sample a grain pose from the range given by inner radius and outer radius. At the moment, it's using uniform distribution.'''
    angle = random.uniform(0, 2*np.pi)
    position = random.uniform(inner_radius, outer_radius)
    return Pose.from_translation_first_then_rotation(Vector(position, 0, 0),
                                                     Vector.e_z(),
                                                     angle)


def randomly_rotate_grain(grain: Grain) -> Grain:
    '''Randomly rotate the grain orientation in 3D.'''
    angle = random.uniform(0, 2*np.pi)
    rotation_axis = Vector(random.uniform(0, 1), random.uniform(
        0, 1), random.uniform(0, 1)).normalize()
    new_grain = grain.update_mesh(grain.get_mesh().transform(
        Transform.from_axis_angle(rotation_axis, angle)))
    return new_grain


class Tool:
    """Generic tool class in different processes. Use factory method to return the corresponding
    tool needed. The intention is to only provide a geometric representation of tool prototype.

    It should have the following attributes:
    pose: a 4x4 matrix orientation and position of the tool
    process: the corresponding process type that the tool is used in.
    """

    pose: Pose
    grains: List[Grain]
    rotation_axis: Vector  # This is where the tool is mounted and the forces apply
    cutting_surface_normal: Vector

    def __init__(self, grains: List[Grain], pose: Pose, rotation_axis=Vector.e_z(), cutting_surface_normal=Vector.e_z().scale(-1)):
        self.grains = grains
        self.pose = pose
        self.rotation_axis = rotation_axis.normalize()
        self.cutting_surface_normal = cutting_surface_normal

    def move(self, pose: Pose):
        self.pose = pose
        return self

    @classmethod
    def from_radius(cls, basic_grain: Grain, inner_radius: float, outer_radius: float,
                    number_of_grains: float, tool_pose: Pose, random_seed_number=0):
        '''Randomly distribute the grains with the same size, based on the inner and outer radius of the tool.
        Random_seed_number controls the reproducibility of the grain distribution.
        The same seed number gives the same distribution of the grains.
        '''
        grain_list = []
        np.random.seed(random_seed_number)
        # TODO: decide if we need different grain size or not
        grainsize_randmultiplier = np.random.uniform(
            0.2, 0.5, size=(number_of_grains))
        # TODO: grain distribution should be randomized based on predetermined grid and sample the deviation that a grain
        # can have to giggle around the grid point.
        for i in range(0, number_of_grains):
            grain_iterator = copy.deepcopy(
                basic_grain.scale(1))
            grain_iterator = randomly_rotate_grain(grain_iterator)
            grain_pose = randomly_sample_grain_pose(inner_radius, outer_radius)
            grain = grain_iterator.move(grain_pose)
            grain_list.append(grain)
        return cls(grain_list, tool_pose)

    def get_grain_positions_in_base_frame(self) -> List[Vector]:
        grain_positions: List[Vector] = Vector.change_frame_point_list([grain.get_position() for grain in self.grains],
                                                                       [self.pose], [])
        return grain_positions

    def get_max_bounding_sphere_radius(self) -> float:
        bounding_sphere_radiuses = [
            grain.bounding_sphere_radius for grain in self.grains]
        return max(bounding_sphere_radiuses)

    def save_to_disk(self, file_name: str):
        with open(file_name, 'wb') as file:
            dill.dump(self, file)

    def add_grains_protrusion_from_distribution(self, distribution_function: Callable[[float], float]):
        '''Protrusion for grains is applied by moving grains along tool cutting surface normal, scaled with given distribution.
        If not modified before or specified otherwise, grain centers are located at tool surface.'''

        direction = self.cutting_surface_normal
        for grain_id, grain in enumerate(self.grains):
            protrusion_vector = direction.scale(
                distribution_function(grain_id))
            grain.pose = grain.pose.transform(
                Transform.from_translation(protrusion_vector))
            grain.center_protrusion = protrusion_vector

    @staticmethod
    def load_from_disk(file_name):
        with open(file_name, 'rb') as file:
            tool = dill.load(file)
        if isinstance(tool, Tool):
            return tool
        else:
            Exception(
                "The loaded tool object is not from the current version of this class.")

    def compare(self, other, precision):
        if isinstance(other, Tool):
            self.pose.compare(other.pose, precision)
            self.rotation_axis.compare(other.rotation_axis, precision)
            self.cutting_surface_normal.compare(
                other.cutting_surface_normal, precision)
            for index in range(0, len(self.grains)):
                self.grains[index].compare(other.grains[index], precision)
        else:
            raise InputAreNotTheSameDataType

# TODO implement state
