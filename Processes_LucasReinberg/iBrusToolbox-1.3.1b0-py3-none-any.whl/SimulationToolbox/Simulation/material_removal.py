from SimulationToolbox.PhysicalObjects import grain
from SimulationToolbox.Simulation.simulation_config import MaterialRemovalConfig
from matplotlib import use
from SimulationToolbox.Simulation.kinematics import Kinematics
import numpy as np
from SimulationToolbox.PhysicalObjects.tool import *
from SimulationToolbox.PhysicalObjects.workpiece import *
from SimulationToolbox.Geometry.geometry import *
from SimulationToolbox.Geometry.geometric_objects import *
from SimulationToolbox.Simulation.collider import *
from SimulationToolbox.Simulation.wear_models import *
from SimulationToolbox.Simulation.kinematics import Kinematics
from SimulationToolbox.Utilities.helpers import *
from typing import *
from statistics import mean

# what is is used for, notes from the design discussion


class PenetrationCalculation:
    max_penetration_depth: float
    penetration_depth_list: List[float]
    penetrated_plane_boundary: pygeos.geometry
    projected_area_boundary: List[Vector]

    def __init__(self, max_penetration_depth: float, penetration_depth_list: List[float], projected_area_boundary: List[Vector], penetrated_plane_boundary: pygeos.geometry):
        self.max_penetration_depth = max_penetration_depth
        self.penetration_depth_list = penetration_depth_list
        self.projected_area_boundary = projected_area_boundary
        self.penetrated_plane_boundary = penetrated_plane_boundary

    def set_penetrated_plane_boundary(self, penetrated_plane_boundary: pygeos.geometry):
        self.penetrated_plane_boundary = penetrated_plane_boundary

    @classmethod
    def from_default_values(cls):
        # set default value for penetration_depth_list, projected_cutting_area_boundary,? maybe an empty list
        return cls(max_penetration_depth=0, penetration_depth_list=[], penetrated_plane_boundary=pygeos.polygons(None), projected_area_boundary=[])


class WearCalculationPrior:
    leading_vertex_index: int
    mesh_indices_pointer_to_projected_area: List[int]

    def __init__(self, leading_vertex_index: int, mesh_indices_pointer_to_projected_area: List[int]):
        self.leading_vertex_index = leading_vertex_index
        self.mesh_indices_pointer_to_projected_area = mesh_indices_pointer_to_projected_area

    @classmethod
    def from_default_values(cls):
        # set default value for leading edge index, max_penetration depth, projected_cutting_area_boundary, mesh_indices_pointer_to_projected_area ? maybe an empty list
        return cls(leading_vertex_index=-1, mesh_indices_pointer_to_projected_area=[])


class OneGrainCrossOnePlaneInfoCollector:
    grain_index: int
    plane_index: int
    current_grain_position_in_plane_frame: Vector
    last_grain_position_in_plane_frame: Vector
    __approach_angle_on_plane: float
    __grain_displacement_in_plane: Vector
    __projected_cutting_area: Area2D
    __intersected_area: Area2D
    distance_to_last_grain_position: float
    distance_to_current_grain_position: float
    __wear_calculation_prior: WearCalculationPrior
    __penetration_calculation: PenetrationCalculation

    def __init__(self, grain_index: int, workpiece: Workpiece,  plane_index: int, current_grain_position_in_plane_frame: Vector, last_grain_position_in_plane_frame: Vector):
        self.grain_index = grain_index
        self.plane_index = plane_index
        self.current_grain_position_in_plane_frame = current_grain_position_in_plane_frame
        self.last_grain_position_in_plane_frame = last_grain_position_in_plane_frame
        self.__approach_angle_on_plane = None
        self.__grain_displacement_in_plane = None
        self.__intersected_area = None
        self.__projected_cutting_area = None
        self.__wear_calculation_prior = None
        self.__penetration_calculation = None
        self.distance_to_current_grain_position = self.get_distance_to_current_grain_position(
            workpiece)
        self.distance_to_last_grain_position = self.get_distance_to_last_grain_position(
            workpiece)

    def get_grain_approach_plane_angle(self, workpiece: Workpiece) -> float:
        self.__approach_angle_on_plane = np.abs(self.grain_displacement_in_plane.normalize().dot(
            workpiece.slices[self.plane_index].get_normal()))
        return self.__approach_angle_on_plane

    def get_projected_grain_position_on_the_plane(self, workpiece: Workpiece) -> Vector:
        '''Calculate the grain projection along displacement to each plane,
        using LAST POSITION of grain to calculate the distance between the point and the projected point in plane
        frame.'''

        plane = workpiece.slices[self.plane_index]
        projected_grain_position_on_the_plane = plane.project_point_onto(
            self.last_grain_position_in_plane_frame, self.grain_displacement_in_plane)
        return projected_grain_position_on_the_plane

    def get_distance_to_last_grain_position(self, workpiece: Workpiece) -> float:
        return self.get_projected_grain_position_on_the_plane(workpiece).subtract(
            self.last_grain_position_in_plane_frame).norm()

    def get_distance_to_current_grain_position(self, workpiece: Workpiece) -> float:
        return self.get_projected_grain_position_on_the_plane(workpiece).subtract(
            self.current_grain_position_in_plane_frame).norm()

    @property
    def wear_calculation_prior(self):
        if self.__wear_calculation_prior is None:
            raise OptionalAttributeNotCalculatedYet(
                "The wear calculation prior is not calculated. Probably because the wear calculation is not required in the material removal config.")
        return self.__wear_calculation_prior

    @property
    def penetration_calculation(self):
        if self.__penetration_calculation is None:
            raise OptionalAttributeNotCalculatedYet
        else:
            return self.__penetration_calculation

    @property
    def grain_displacement_in_plane(self):
        if self.__grain_displacement_in_plane is None:
            self.__grain_displacement_in_plane = self.current_grain_position_in_plane_frame.subtract(
                self.last_grain_position_in_plane_frame)
        return self.__grain_displacement_in_plane

    @property
    def approach_angle_on_plane(self):
        if self.__approach_angle_on_plane is None:
            raise OptionalAttributeNotCalculatedYet
        else:
            return self.__approach_angle_on_plane

    @property
    def intersected_area(self):
        if self.__intersected_area is None:
            raise OptionalAttributeNotCalculatedYet
        else:
            return self.__intersected_area

    @property
    def projected_cutting_area(self):
        if self.__projected_cutting_area is None:
            # calculate the size of projected cutting area to a plane
            # perpendicular to displacement
            self.__projected_cutting_area = self.intersected_area.size(
            ) * np.abs(self.approach_angle_on_plane)
        return self.__projected_cutting_area

    def set_intersected_area(self, intersected_area: Area2D):
        self.__intersected_area = intersected_area

    def get_penetration_calculation(self, wp: Workpiece, projected_area_boundary):
        penetration_depth_list = calculate_penetration_depth_list(
            wp.slices[self.plane_index], self.penetration_calculation.penetrated_plane_boundary, projected_area_boundary)
        self.__penetration_calculation = PenetrationCalculation(max(penetration_depth_list),
                                                                penetration_depth_list, projected_area_boundary, self.penetration_calculation.penetrated_plane_boundary)

    def set_penetration_calculation(self, penetration_calculation: PenetrationCalculation):
        self.__penetration_calculation = penetration_calculation

    def get_wear_calculation_prior(self, mesh_indices_pointer_to_projected_area):
        leading_vertex_index = calculate_leading_vertex_index(
            self.penetration_calculation.penetration_depth_list, mesh_indices_pointer_to_projected_area)
        self.__wear_calculation_prior = WearCalculationPrior(
            leading_vertex_index, mesh_indices_pointer_to_projected_area)

    def set_wear_calculation_prior(self, wear_calculation_prior: WearCalculationPrior):
        self.__wear_calculation_prior = wear_calculation_prior

    def set_penerated_plane_area_boundary(self, current_intersected_area: Area2D, wp: Workpiece):

        intersected_area_largest_part = pygeos.boundary(sorted(pygeos.get_parts(
            self.intersected_area.area), key=lambda a: pygeos.area(a), reverse=True)[0])
        plane_area_boundary = pygeos.boundary(
            wp.slices[self.plane_index].area.area)

        difference_plane_current_intersected_area = []
        for part in pygeos.get_parts(current_intersected_area.area):
            difference_plane_current_intersected_area.append(
                pygeos.difference(pygeos.boundary(part), plane_area_boundary, grid_size=default_precision))

        for part in difference_plane_current_intersected_area:
            intersected_area_largest_part = pygeos.difference(
                intersected_area_largest_part, part, grid_size=default_precision)

        penetrated_plane_boundary = intersected_area_largest_part

        # convert penetrated plane boundary to a single linestring (if not already)
        if pygeos.get_type_id(penetrated_plane_boundary) == 5:
            penetrated_plane_boundary = pygeos.line_merge(
                penetrated_plane_boundary)

        if pygeos.get_type_id(penetrated_plane_boundary) != 1:
            if pygeos.get_type_id(penetrated_plane_boundary) == 5:
                penetrated_plane_boundary = pygeos.linestrings(
                    pygeos.get_coordinates(penetrated_plane_boundary))
            else:
                raise Exception(
                    'Unexpected geometry type for penetrated_plane_boundary')

        self.penetration_calculation.set_penetrated_plane_boundary(
            penetrated_plane_boundary)


class OneGrainCrossedPlanesInfo:
    individual_collector: List[OneGrainCrossOnePlaneInfoCollector]

    def __init__(self, list_of_single_collector: List[OneGrainCrossOnePlaneInfoCollector]):
        self.individual_collector = list_of_single_collector

    def generate_areas_and_distances_pair(self, workpiece: Workpiece, current_step_grain_inside_wp: bool, last_step_grain_inside_wp: bool, last_projected_cutting_area_of_grain: Area2D):
        # Sort the plane index based on the distance of last grain position  to planes
        # TODO: Check if we can reduce the use of dictionary when getting the distance between planes
        # and sorting the planes
        self.individual_collector = sorted(
            self.individual_collector, key=lambda event: event.distance_to_last_grain_position)

        # the length of between_plane_distance is len(self.individual_events) -1
        between_plane_distance = []
        for index in range(1, len(self.individual_collector)):
            between_plane_distance.append(
                self.individual_collector[index].get_distance_to_last_grain_position(workpiece) - self.individual_collector[index-1].distance_to_last_grain_position)
        # the length of area_list is the len(self.individual_events)
        target_area_list = [
            event.projected_cutting_area for event in self.individual_collector[:-1]]
        target_distance_list = between_plane_distance

        if current_step_grain_inside_wp:
            target_distance_list.append(
                self.individual_collector[-1].distance_to_current_grain_position)
            target_area_list.append(
                self.individual_collector[-1].projected_cutting_area)
        if last_step_grain_inside_wp:
            target_distance_list.insert(
                0,  self.individual_collector[0].distance_to_last_grain_position)
            target_area_list.insert(0, last_projected_cutting_area_of_grain)

        return target_area_list, target_distance_list

    def get_projected_cutting_areas_and_removed_volume(self, workpiece: Workpiece, current_step_grain_inside_wp: bool, last_step_grain_inside_wp: bool, last_projected_cutting_area_of_grain: Area2D):
        target_areas_list, target_distances_list = self.generate_areas_and_distances_pair(
            workpiece, current_step_grain_inside_wp, last_step_grain_inside_wp, last_projected_cutting_area_of_grain)

        if len(target_areas_list) == len(target_distances_list):
            # calculate removed volume
            volume = 0
            for index in range(len(target_distances_list)):
                volume += target_areas_list[index] * \
                    target_distances_list[index]
        else:
            raise Exception(
                "The target_area and target_distance lists doesn't match")

        return [event.projected_cutting_area for event in self.individual_collector], volume

    def get_max_penetration_depth_all_planes(self):
        # find the grain plane cross that has the maximal pentration depth
        self.individual_collector = sorted(
            self.individual_collector, key=lambda event: event.penetration_calculation.max_penetration_depth, reverse=True)

        if self.individual_collector[0].penetration_calculation.max_penetration_depth < default_precision:
            max_penetration_depth_all_planes = 0
        else:
            max_penetration_depth_all_planes = self.individual_collector[
                0].penetration_calculation.max_penetration_depth

        return max_penetration_depth_all_planes

    def get_wear_direction_and_leading_vertex_index_all_planes(self, wp: Workpiece, tool: Tool):
        '''Based on the penetration depth of each grain and each plane, calculate a max penetration depth and wear direction based
        on the point that the max_penetration happens.'''

        if self.individual_collector[0].penetration_calculation.max_penetration_depth < default_precision:
            wear_direction_in_grain_frame = Vector.origin()
            leading_vertex_index_all_planes = -1

            return wear_direction_in_grain_frame, leading_vertex_index_all_planes

        else:
            wear_direction_in_grain_frame = calculate_wear_direction(
                wp, tool, self.individual_collector[0])

            leading_vertex_index_all_planes = self.individual_collector[
                0].wear_calculation_prior.leading_vertex_index

            return wear_direction_in_grain_frame, leading_vertex_index_all_planes


class GrainsCrossedPlanes:
    individual_events: List[OneGrainCrossedPlanesInfo]

    def __init__(self, list_of_single_events: List[OneGrainCrossedPlanesInfo]):
        self.individual_events = list_of_single_events


class MaterialRemovalResult:
    removed_volumes: List[float]  # indices matches indices of grains in tool
    projected_areas: List[float]  # indices matches indices of grains in tool
    penetration_depths: List[float]
    leading_vertex_indices: List[int]
    wear_directions: List[Vector]
    # represented in base_frame of tool and wp
    grains_displacement: List[Vector]
    exist_too_small_approach_angles: bool

    # TODO add grains displacement to tests in mat removal or at least test displacements once!
    def __init__(self, removed_volumes: List[float],
                 projected_areas: List[float], penetration_depths: List[float] = [],
                 leading_vertex_indices: List[int] = [], wear_directions: List[Vector] = [], grains_displacement: List[Vector] = []):
        self.removed_volumes = removed_volumes
        self.projected_areas = projected_areas
        self.grains_displacement = grains_displacement
        self.penetration_depths = penetration_depths
        self.leading_vertex_indices = leading_vertex_indices
        self.wear_directions = wear_directions
        self.exist_too_small_approach_angles = False

    @ classmethod
    def from_all_empty(cls, tool: tool.Tool):
        removed_volume = [0.0] * len(tool.grains)
        projected_areas = [0.0] * len(tool.grains)
        penetration_depths = [0.0] * len(tool.grains)
        leading_vertex_indices = [-1] * len(tool.grains)
        wear_directions = [Vector.origin() for k in range(len(tool.grains))]
        grains_displacement = [Vector.origin()]*len(tool.grains)
        return cls(removed_volume, projected_areas, penetration_depths, leading_vertex_indices, wear_directions, grains_displacement)

    def compare(self, other, precision):
        if isinstance(other, MaterialRemovalResult):
            assert len(self.removed_volumes) == len(other.removed_volumes)
            assert len(self.projected_areas) == len(other.projected_areas)
            compare_np_arrays(self.removed_volumes,
                              other.removed_volumes, precision)
            compare_np_arrays(self.projected_areas,
                              other.projected_areas, precision)
        else:
            raise Exception('input not of type MaterialRemovalResult')

    def compare_wear_input_variables(self, other, precision):
        if isinstance(other, MaterialRemovalResult):
            assert len(self.penetration_depths) == len(
                other.penetration_depths)
            assert len(self.leading_vertex_indices) == len(
                other.leading_vertex_indices)
            assert len(self.wear_directions) == len(
                other.wear_directions)
            compare_np_arrays(self.penetration_depths,
                              other.penetration_depths, precision)
            compare_np_arrays(self.leading_vertex_indices,
                              other.leading_vertex_indices, precision)
            for index, vector in enumerate(self.wear_directions):
                vector.compare(other.wear_directions[index], default_precision)
        else:
            raise Exception('input not of type MaterialRemovalResult')


class MaterialRemover:
    collider: Collider
    # TODO: in current MRR model, the attributes of MaterialRemover class are not tested.
    # So essentically at what condition the model should inherit result from previous step is not explicitly tested.
    # Instead there is only test based on MaterialRemovalResult class. To make debugging easier, tests on these attributes should be included.
    last_grains_positions_in_global_frame: List[Vector]
    last_grains_positions_in_wp_frame: List[Vector]
    # [plane_index][active_grain_idx]
    last_active_grains_positions_in_plane_frame: List[List[Vector]]
    last_active_grain_index_in_tool_nparray: np.ndarray  # [int]
    last_projected_cutting_areas: List[float]  # projection of the cutting
    # are to a plane perpendicular to the velocity vector
    last_penetration_depths: List[float]  # penetration of the cutting grains
    # leading vertex of the cutting grains
    last_leading_vertex_indices: List[int]
    last_wear_directions: List[Vector]
    last_tool_pose: Pose
    # are to a plane perpendicular to the displacement vector
    grains_inside_wp_last: List[bool]   # true: inside wp, false: outside
    exist_approach_angle_too_small: bool
    config: MaterialRemovalConfig

    def __init__(self, workpiece: Workpiece, tool: tool.Tool,
                 current_tool_pose: Pose, kinematics: Kinematics, mat_remover_config: MaterialRemovalConfig):

        self.config = mat_remover_config

        self.collider = Collider(
            tool.move(current_tool_pose), workpiece, mat_remover_config.collider_config)
        if self.config.use_reduced_grain:
            self.calculated_grain_mesh_displacement(
                tool, kinematics, self.collider)
        self.last_grains_positions_in_global_frame = self.collider.current_grains_positions_in_global_frame
        self.last_grains_positions_in_wp_frame = self.collider.current_grains_positions_in_wp_frame
        self.last_active_grains_positions_in_plane_frame = self.collider.current_active_grains_positions_in_plane_frame
        self.last_active_grain_index_in_tool_nparray = self.collider.current_active_grain_index_in_tool_nparray
        self.last_tool_pose = current_tool_pose

        self.last_projected_cutting_areas = [0.0] * len(tool.grains)
        self.last_penetration_depths = [0.0] * len(tool.grains)
        # -1 index indicates no grain-plane interaction has occured
        self.last_leading_vertex_indices = [-1] * len(tool.grains)
        self.last_wear_directions = [Vector.origin()
                                     for k in range(len(tool.grains))]
        self.grains_inside_wp_last = [
            False] * len(tool.grains)
        if self.config.check_approach_angle:
            self.exist_approach_angle_too_small = self.check_approach_angle(
                tool, workpiece, kinematics, mat_remover_config)
            # Rest values after check
            self.collider = Collider(
                tool.move(current_tool_pose), workpiece, mat_remover_config.collider_config)
            self.last_grains_positions_in_global_frame = self.collider.current_grains_positions_in_global_frame
            self.last_grains_positions_in_wp_frame = self.collider.current_grains_positions_in_wp_frame
            self.last_active_grains_positions_in_plane_frame = self.collider.current_active_grains_positions_in_plane_frame
            self.last_active_grain_index_in_tool_nparray = self.collider.current_active_grain_index_in_tool_nparray
            self.last_tool_pose = current_tool_pose

            self.last_projected_cutting_areas = [0.0] * len(tool.grains)
            self.last_penetration_depths = [0.0] * len(tool.grains)
            self.last_leading_vertex_indices = [-1] * len(tool.grains)
            self.last_wear_directions = [
                Vector.origin() for k in range(len(tool.grains))]
            self.grains_inside_wp_last = [
                False] * len(tool.grains)

    @ staticmethod
    def calculated_grain_mesh_displacement(tool: Tool, kin: Kinematics, first_step_collider: Collider):
        '''Calculate the grain displacement in grain frame and generate reduced grain'''
        grain_positions_first_step = first_step_collider.current_grains_positions_in_global_frame
        second_step_tool = copy.deepcopy(
            tool).move(kin.ToolTrajectory.poses[1])
        grain_positions_second_step = second_step_tool.get_grain_positions_in_base_frame()

        for idx, grain in enumerate(tool.grains):
            grain_displacement_in_base_frame = grain_positions_second_step[idx].subtract(
                grain_positions_first_step[idx])
            up_chain = [tool.pose, tool.grains[idx].pose]
            grain_displacement_in_grain_frame = grain_displacement_in_base_frame.change_frame_vector([
            ], up_chain)

            # project_mesh_along_velocity
            projected_mesh = grain.get_mesh().transform(
                Transform.from_projection_along_vector_to_x_z_plane(grain_displacement_in_grain_frame))
            projected_fm = projected_mesh.to_flatmanifold(default_precision)
            grain.generate_reduced_grain(
                ReducedGrain(grain_displacement_in_grain_frame, projected_mesh, projected_fm))

    def check_approach_angle(self, tool: Tool, workpiece: Workpiece, kinematics: Kinematics, mat_remover_config: MaterialRemovalConfig):
        # A small simulation loop stays here
        debug_index_tool_pose = 0
        for current_tool_pose in kinematics.ToolTrajectory.poses:
            approach_angle_check_result = self.update(
                workpiece, tool, current_tool_pose, mat_remover_config, remove_material=False)
            debug_index_tool_pose += 1

        return approach_angle_check_result.exist_too_small_approach_angles

    @ staticmethod
    def using_mesh_solution(grain: Grain, workpiece_slice: FlatManifold,
                            tool_to_global_frame_change: Transform,
                            global_to_plane_frame_change_transform: Transform,
                            grain_displacement_in_plane_frame: Vector, material_removal_config: MaterialRemovalConfig) -> Tuple[Area2D, List[Vector], List[Vector]]:
        mesh_in_tool_frame = grain.get_mesh().change_frame(
            [grain.pose], [])

        mesh_in_plane_frame = mesh_in_tool_frame.transform(
            tool_to_global_frame_change.concatenate(
                global_to_plane_frame_change_transform))
        projected_mesh = workpiece_slice.project_mesh_onto(
            mesh_in_plane_frame, grain_displacement_in_plane_frame)
        projected_area = projected_mesh.to_area2D(
            default_precision)
        projected_area_boundary = projected_area.get_boundary_points()

        mesh_indices_for_projected_area_points = []
        if material_removal_config.apply_wear:
            for point in projected_area_boundary:
                for index, vertex in enumerate(projected_mesh.vertices):
                    if point.x() == vertex.x() and point.z() == vertex.z():
                        mesh_indices_for_projected_area_points.append(
                            index)
                        break
            grain.get_mesh().set_mesh_indices_corresponds_to_projected_area2_points(
                mesh_indices_for_projected_area_points)

        return projected_area, projected_area_boundary, mesh_indices_for_projected_area_points

    @ staticmethod
    def using_reduced_grain_solution(grain: Grain, workpiece_slice: FlatManifold,
                                     tool_to_global_frame_change: Transform,
                                     global_to_plane_frame_change_transform: Transform,
                                     grain_displacement_in_plane_frame: Vector, material_removal_config: MaterialRemovalConfig) -> Tuple[Area2D, List[Vector]]:
        fm_points_in_tool_frame = Vector.change_frame_point_list(grain.reduced_grain.projected_area.get_boundary_points_in_base_frame(), [grain.pose],
                                                                 [])
        fm_points_in_plane_frame = [point.transform(
            tool_to_global_frame_change.concatenate(global_to_plane_frame_change_transform)) for point in fm_points_in_tool_frame]

        projected_area = workpiece_slice.project_flatmanifold_points_onto(
            fm_points_in_plane_frame, grain_displacement_in_plane_frame)

        mesh_indices_for_fm_points = []
        if material_removal_config.apply_wear:

            for point_idx, point in enumerate(grain.reduced_grain.projected_area.area.get_boundary_points()):
                for vertex_idx, vertex in enumerate(grain.reduced_grain.projected_mesh_ancestor.vertices):
                    if point.x() == vertex.x() and point.z() == vertex.z():
                        mesh_indices_for_fm_points.append(
                            vertex_idx)
                        break
            grain.reduced_grain.set_mesh_indices_corresponds_to_projected_fm_points(
                mesh_indices_for_fm_points)

        return projected_area, mesh_indices_for_fm_points

    def register_grain_area_on_plane(self, workpiece: Workpiece, tool: Tool, last_tool_to_global_frame_change: Transform, global_to_plane_frame_change: Transform, grain_meet_plane_event: OneGrainCrossOnePlaneInfoCollector, material_removal_config: MaterialRemovalConfig):
        '''Calculate the intersected area on the plane,
        register the accumulated intersected area of the grain on to plane,
        return the boundary of projected area,'''

        plane = workpiece.slices[grain_meet_plane_event.plane_index]

        if self.config.use_reduced_grain is True:
            projected_area, mesh_indices_for_fm_points = self.using_reduced_grain_solution(
                tool.grains[grain_meet_plane_event.grain_index], plane, last_tool_to_global_frame_change, global_to_plane_frame_change, grain_meet_plane_event.grain_displacement_in_plane, material_removal_config)
            projected_area_boundary = projected_area.get_boundary_points()
            mesh_indices_list = mesh_indices_for_fm_points
        elif self.config.use_reduced_grain is False:
            projected_area, projected_area_boundary, mesh_indices_for_projected_area_points = self.using_mesh_solution(
                tool.grains[grain_meet_plane_event.grain_index], plane, last_tool_to_global_frame_change, global_to_plane_frame_change, grain_meet_plane_event.grain_displacement_in_plane, material_removal_config)
            mesh_indices_list = mesh_indices_for_projected_area_points

        # calculate projected cutting area perpendicular to displacement
        current_intersected_area = plane.area.intersect(
            projected_area)

        if pygeos.is_empty(plane.registered_area.area):
            intersected_area = current_intersected_area
            area_to_register = current_intersected_area
        else:
            intersected_area = current_intersected_area.remove_area(
                plane.registered_area)
            if intersected_area.size() > default_precision:
                area_to_register = plane.registered_area.union(
                    current_intersected_area)
            else:
                area_to_register = plane.registered_area

        plane.register_area(RegisteredAreaOnPlane(
            grain_meet_plane_event.plane_index, area_to_register))

        grain_meet_plane_event.set_intersected_area(intersected_area)

        grain_meet_plane_event.set_penetration_calculation(
            PenetrationCalculation.from_default_values())

        # Check if grain has not intersected the plane
        if grain_meet_plane_event.intersected_area.size() > default_precision:
            # TODO: Check if grain is punching through plane, not crossing boundary
            # attempted solution below fails
            # if not pygeos.crosses(projected_area.area, plane.area.area):
            #     grain_meet_plane_event.penetration_calculation.set_penetrated_plane_boundary(
            #         pygeos.boundary(plane.area.area))
            # else:
            grain_meet_plane_event.set_penerated_plane_area_boundary(current_intersected_area,
                                                                     workpiece)
            grain_meet_plane_event.get_penetration_calculation(
                workpiece, projected_area_boundary)

            if material_removal_config.apply_wear:
                grain_meet_plane_event.get_wear_calculation_prior(
                    mesh_indices_list)

    def update(self, workpiece: Workpiece,
               tool: Tool, current_tool_pose: Pose,
               mat_remover_config: MaterialRemovalConfig,
               remove_material: bool = True) -> MaterialRemovalResult:

        # get grain-slice intersection pairs
        current_tool = tool.move(current_tool_pose)
        last_tool_to_global_frame_change = Transform.get_frame_change_transform(
            [self.last_tool_pose], [])

        # Compare bounding_sphere_radius with maximum_distance_travelled_by_grain
        max_grain_bounding_sphere_radius = current_tool.get_max_bounding_sphere_radius()
        if mat_remover_config.collider_config.collision_detection_threshold > max_grain_bounding_sphere_radius:
            pass
        else:
            mat_remover_config.collider_config.collision_detection_threshold = max_grain_bounding_sphere_radius

        collider_result = self.collider.update(
            current_tool, workpiece, mat_remover_config.collider_config)

        # calculate grains displacement in base frame of tool and workpiece
        # TODO test grains displacement in matRemoverResult
        result = MaterialRemovalResult.from_all_empty(tool)
        result.grains_displacement = [position.
                                      subtract(self.last_grains_positions_in_global_frame[grain_id]) for grain_id, position in enumerate(self.collider.current_grains_positions_in_global_frame)]

        # iterating the grains from the tool at last timestep
        for grain_idx, grain in enumerate(tool.grains):
            if collider_result.grains_in_workpiece_proximity[grain_idx] and not grain.pullout:
                # Because based on our setting: collider_proximity = one grain timestep,
                # so if this step the grain position is inside workpiece, the on the previous step,
                # the grain must have been in collider proximity
                projected_cutting_area: float = []
                grain_crossed_multiple_planes = OneGrainCrossedPlanesInfo([
                ])
                # Take out all the planes that grains has crossed
                # from last time step till this timestep
                indices = [i for i, result in enumerate(
                    collider_result.grains_crossed_planes[grain_idx]) if result is True]
                # TODO: when looping through the grains that has passed planes in the last timestep, do this: sort the grains based on their distance to the crossed planes. The furtherst grain remove material firs.
                # why: when 2 grains passing a plane and one grain is behind the other, then the index of the grain determins which grain will interact first. However, this index is randomly generated. The grain in the front doesn't necessarily get the first index.
                # But in reality it should remove the material first.
                if len(indices) != 0:
                    for crossed_plane_index in indices:
                        # calculate displacement in plane frame
                        grain_idx_in_current_active_grain_list = self.collider.current_active_grain_index_in_tool_nparray.tolist().index(grain_idx)
                        grain_idx_in_last_active_grain_list = self.last_active_grain_index_in_tool_nparray.tolist().index(grain_idx)

                        grain_meet_plane = OneGrainCrossOnePlaneInfoCollector(
                            grain_idx, workpiece, crossed_plane_index, self.collider.current_active_grains_positions_in_plane_frame[
                                crossed_plane_index][grain_idx_in_current_active_grain_list],
                            self.last_active_grains_positions_in_plane_frame[crossed_plane_index][grain_idx_in_last_active_grain_list])

                        grain_meet_plane.get_grain_approach_plane_angle(
                            workpiece)

                        # check approach angle
                        if np.pi/2 - np.arccos(grain_meet_plane.approach_angle_on_plane) < np.pi/4:
                            result.exist_too_small_approach_angles = True
                            print("Warning: approach angle smaller than 45 degrees. Approach angel is", np.degrees(np.pi /
                                  2 - np.arccos(grain_meet_plane.approach_angle_on_plane)), "degrees")

                        # if we only check approach angle and don't remove material, then we skip the rest of calculations.
                        if not remove_material:
                            continue

                        global_to_plane_frame_change = self.collider.global_to_wp_frame_transform.concatenate(
                            self.collider.workpiece_to_plane_transform[crossed_plane_index])
                        if mat_remover_config.apply_wear:
                            grain_meet_plane.set_wear_calculation_prior(
                                WearCalculationPrior.from_default_values())

                        self.register_grain_area_on_plane(
                            workpiece, tool, last_tool_to_global_frame_change, global_to_plane_frame_change, grain_meet_plane, mat_remover_config)

                        grain_crossed_multiple_planes.individual_collector.append(
                            grain_meet_plane)

                    # if we only check approach angle and don't remove material, then we skip the rest of calculations.
                    if not remove_material:
                        continue

                    projected_cutting_areas_list, volume = grain_crossed_multiple_planes.get_projected_cutting_areas_and_removed_volume(
                        workpiece, collider_result.grains_inside_workpiece[grain_idx], self.grains_inside_wp_last[grain_idx], self.last_projected_cutting_areas[grain_idx])

                    max_penetration_depth_all_planes = grain_crossed_multiple_planes.get_max_penetration_depth_all_planes()

                    if mat_remover_config.apply_wear:
                        wear_direction_in_grain_frame, leading_vertex_index_all_planes = grain_crossed_multiple_planes.get_wear_direction_and_leading_vertex_index_all_planes(
                            workpiece, tool)
                    else:
                        wear_direction_in_grain_frame = Vector.origin()
                        leading_vertex_index_all_planes = -1

                    projected_cutting_area = mean(projected_cutting_areas_list)
                    last_projected_cutting_area = projected_cutting_areas_list[-1]
                    last_penetration_depth = max_penetration_depth_all_planes
                    last_leading_vertex_index = leading_vertex_index_all_planes
                    last_wear_direction = wear_direction_in_grain_frame

                    # if this is a single plane workpiece, then it
                    # should return 0 volume but projected cutting area.
                    if len(workpiece.slices) == 1:
                        volume = 0

                # if a grain didn't pass any plane in a timestep, we differentiate
                # 1. if this is a single plane workpiece:
                #   we still try to calculate the projected area and
                #   removed volume only when this or last time step is in the workpiece
                # 2. Else: we only remove from last time step to this time step, when the grain is inside workpiece at current time step
                else:
                    max_penetration_depth_all_planes = 0
                    leading_vertex_index_all_planes = -1
                    wear_direction_in_grain_frame = Vector.origin()

                    if collider_result.grains_inside_workpiece[grain_idx]:
                        last_projected_cutting_area = self.last_projected_cutting_areas[grain_idx]
                        volume = last_projected_cutting_area *\
                            self.collider.current_grains_positions_in_global_frame[grain_idx].subtract(
                                self.last_grains_positions_in_global_frame[grain_idx]).norm()
                        projected_cutting_area = last_projected_cutting_area
                        # if this is a single plane workpiece, then it should
                        # return 0 volume but projected cutting
                        # area.
                        if len(workpiece.slices) == 1:
                            volume = 0
                        last_penetration_depth = self.last_penetration_depths[grain_idx]
                        last_leading_vertex_index = self.last_leading_vertex_indices[grain_idx]
                        last_wear_direction = self.last_wear_directions[grain_idx]
                        max_penetration_depth_all_planes = last_penetration_depth
                        leading_vertex_index_all_planes = last_leading_vertex_index
                        wear_direction_in_grain_frame = last_wear_direction
                    else:
                        # This step only happens in two situation:
                        # 1) Grain is entering from the outside world into collision_wp_proximity, or
                        # 2) Grain is entering from removed_material_proximity into collision_wp_proximity, but didn't cross any planes
                        last_projected_cutting_area = 0
                        last_penetration_depth = 0
                        last_leading_vertex_index = -1
                        last_wear_direction = Vector.origin()
                        projected_cutting_area = 0
                        volume = 0

                # write results to material removal result structure
                result.projected_areas[grain_idx] = projected_cutting_area
                result.removed_volumes[grain_idx] = volume
                result.penetration_depths[grain_idx] = max_penetration_depth_all_planes
                result.leading_vertex_indices[grain_idx] = leading_vertex_index_all_planes
                result.wear_directions[grain_idx] = wear_direction_in_grain_frame
            elif grain.pullout:
                # The case when grain is pulled out
                last_projected_cutting_area = 0
                last_penetration_depth = 0
                last_leading_vertex_index = -1
                last_wear_direction = Vector.origin()
                result.projected_areas[grain_idx] = 0
                result.removed_volumes[grain_idx] = 0
                result.penetration_depths[grain_idx] = 0
                result.leading_vertex_indices[grain_idx] = -1
                result.wear_directions[grain_idx] = Vector.origin()
            else:
                # The case when the grain at this time step is not in proximity and not pulled out
                last_projected_cutting_area = 0
                last_penetration_depth = 0
                last_leading_vertex_index = -1
                last_wear_direction = Vector.origin()
                result.projected_areas[grain_idx] = 0
                result.removed_volumes[grain_idx] = 0
                result.penetration_depths[grain_idx] = 0
                result.leading_vertex_indices[grain_idx] = -1
                result.wear_directions[grain_idx] = Vector.origin()

            # store projected cutting are of current grain
            self.last_projected_cutting_areas[grain_idx] = last_projected_cutting_area
            # store info of last grain penetration
            self.last_penetration_depths[grain_idx] = last_penetration_depth
            self.last_leading_vertex_indices[grain_idx] = last_leading_vertex_index
            self.last_wear_directions[grain_idx] = last_wear_direction
            # store the grain wp proximity result for this grain
            self.grains_inside_wp_last[grain_idx] = collider_result.grains_inside_workpiece[grain_idx]

        self.remove_material_from_planes_together(
            workpiece)
        # store all grain positions for next time
        self.last_grains_positions_in_global_frame = self.collider.current_grains_positions_in_global_frame
        self.last_grains_positions_in_wp_frame = self.collider.current_grains_positions_in_wp_frame
        self.last_active_grains_positions_in_plane_frame = self.collider.current_active_grains_positions_in_plane_frame
        self.last_active_grain_index_in_tool_nparray = self.collider.current_active_grain_index_in_tool_nparray
        self.last_tool_pose = current_tool.pose

        return result

    def remove_material_from_planes_together(self, workpiece: Workpiece):
        # remove material all together
        for slice_no, slice in enumerate(workpiece.slices):
            if not pygeos.is_empty(slice.registered_area.area):
                slice.area = slice.area.remove_area(slice.registered_area)
                slice.register_area(
                    RegisteredAreaOnPlane(slice_no, Area2D.empty()))
