"""This module holds the Kinematic class"""
from SimulationToolbox.PhysicalObjects.tool import Tool
import copy
from SimulationToolbox.Geometry.geometry import Pose, PoseTrajectory
from typing import *
from SimulationToolbox.Geometry.geometry import Vector
from SimulationToolbox.PhysicalObjects import *
import dill

from SimulationToolbox.Utilities.helpers import InputAreNotTheSameDataType


class Kinematics:
    """This class holds the transformation matrix in the trajectory, to represent
    the moving track of the tool.
    """
    ToolTrajectory: PoseTrajectory

    def __init__(self, ToolTrajectory: PoseTrajectory):
        self.ToolTrajectory = ToolTrajectory

    @classmethod
    def from_feedrate_and_rotation_speed(cls, start_point: Vector, rotation_axis: Vector,
                                         rotational_speed: float, feed: Vector,
                                         end_time: float, time_step_size: float):
        return cls(PoseTrajectory.from_feedrate_and_rotation_speed(start_point, rotation_axis,
                                                                   rotational_speed, feed, end_time,
                                                                   time_step_size))

    @staticmethod
    def get_max_travelled_distance_of_grains(tool: Tool, pose_trajectory: PoseTrajectory,
                                             up_scaling_precision_factor=float(1 + 1e-5)):
        tool_c = tool
        travelled_distances = []

        tool_current = tool_c.move(pose_trajectory.poses[0])
        current_grain_positions_in_base_frame = tool.get_grain_positions_in_base_frame()

        for pose in pose_trajectory.poses[1:]:
            tool_current = tool_c.move(pose)
            new_grain_positions_in_base_frame = tool_current.get_grain_positions_in_base_frame()
            travelled_distances += [new_grain_position.distance(old_grain_position) for new_grain_position, old_grain_position in zip(
                new_grain_positions_in_base_frame, current_grain_positions_in_base_frame)]
            current_grain_positions_in_base_frame = new_grain_positions_in_base_frame
        return (max(travelled_distances) * up_scaling_precision_factor)

    def save_to_disk(self, file_name: str):
        with open(file_name, 'wb') as file:
            dill.dump(self, file)

    def combine(self, other):
        if isinstance(other, Kinematics):
            return Kinematics(self.ToolTrajectory.extend_trajectory(other.ToolTrajectory))
        else:
            raise InputAreNotTheSameDataType

    @staticmethod
    def load_from_disk(file_name):
        # TODO: "wp" in the following lines should be replaced by "kin". Also check for similar typo cases.
        with open(file_name, 'rb') as file:
            kin = dill.load(file)
        if isinstance(kin, Kinematics):
            return kin
        else:
            Exception(
                "The loaded Kinematics object is not from the current version of this class.")
