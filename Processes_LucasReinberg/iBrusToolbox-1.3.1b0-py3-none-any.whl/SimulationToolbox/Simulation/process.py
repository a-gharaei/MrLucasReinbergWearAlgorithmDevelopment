"""This file holds the process class"""
from SimulationToolbox.PhysicalObjects.workpiece import *
from SimulationToolbox.PhysicalObjects.tool import *
from SimulationToolbox.Simulation.kinematics import *
from typing import *
from typing import Callable


class Process:
    """This class is used for giving a clustered interface for different simulation
    process and its key elements
    """
    tool: Tool
    workpiece: Workpiece
    kinematics: Kinematics

    def __init__(self, tool: Tool, workpiece: Workpiece, kinematics: Kinematics):
        self.tool = tool
        self.workpiece = workpiece
        self.kinematics = kinematics
