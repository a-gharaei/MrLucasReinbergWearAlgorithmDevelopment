from SimulationToolbox.Simulation.simulation_config import CollisionDetectionConfig
import numpy as np
from SimulationToolbox.PhysicalObjects import tool, workpiece
from typing import *
from SimulationToolbox.Geometry.geometry import *
from SimulationToolbox.Geometry.geometric_objects import *
from SimulationToolbox.PhysicalObjects.workpiece import *
from SimulationToolbox.PhysicalObjects.tool import *


class ColliderResult:
    # [grain_idx], those [grain_idx] is corresponding to the grain_idx in the tool.grains list.
    grains_inside_workpiece: List[bool]
    grains_in_workpiece_proximity: List[bool]  # [grain_idx]
    grains_crossed_planes: List[List[bool]]  # [grain_idx][plane_idx]
    # TODO: distance to the planes is not used? Then we don't need to store it
    grains_in_planes_proximity: List[List[bool]]  # [grain_idx][plane_idx]
    grains_on_frontside_of_planes: List[List[bool]]  # [grain_idx][plane_idx]

    def __init__(self,
                 grains_inside_workpiece: List[bool],
                 grains_in_workpiece_proximity: List[bool],
                 grains_crossed_planes: List[List[bool]],
                 grains_in_plains_proximity: List[List[bool]],
                 grains_on_frontside_of_planes: List[List[bool]]
                 ):
        self.grains_inside_workpiece = grains_inside_workpiece
        self.grains_in_workpiece_proximity = grains_in_workpiece_proximity
        self.grains_crossed_planes = grains_crossed_planes
        self.grains_in_planes_proximity = grains_in_plains_proximity
        self.grains_on_frontside_of_planes = grains_on_frontside_of_planes

    @ classmethod
    def from_all_false(cls, nr_grains: int, nr_planes: int):
        grains_inside_workpiece = [False]*nr_grains
        grains_in_workpiece_proximity = [False]*nr_grains
        grains_crossed_planes = [
            [False] * nr_planes for j in range(nr_grains)]
        grains_in_planes_proximity = [
            [False] * nr_planes for j in range(nr_grains)]
        grains_on_frontside_of_planes = [
            [False] * nr_planes for j in range(nr_grains)]

        return cls(grains_inside_workpiece,
                   grains_in_workpiece_proximity,
                   grains_crossed_planes,
                   grains_in_planes_proximity,
                   grains_on_frontside_of_planes)

    def compare(self, other):
        if isinstance(other, ColliderResult):
            assert self.grains_inside_workpiece == other.grains_inside_workpiece
            assert self.grains_in_workpiece_proximity == other.grains_in_workpiece_proximity
            assert self.grains_crossed_planes == other.grains_crossed_planes
            assert self.grains_in_planes_proximity == other.grains_in_planes_proximity
            assert self.grains_on_frontside_of_planes == other.grains_on_frontside_of_planes
        else:
            raise InputAreNotTheSameDataType


class Collider:
    '''The collider class is used to determine the active grains that
    will have potential collision with planes at the current time step.
    '''
    collider_result: ColliderResult
    global_to_wp_frame_transform: Transform
    workpiece_to_plane_transform: List[Transform]  # [plane_idx]
    current_grains_positions_in_global_frame: List[Vector]  # [grain_idx]
    current_grains_positions_in_wp_frame: List[Vector]  # [grain_idx]
    # [plane_index][active_grain_idx]
    current_active_grains_positions_in_plane_frame: List[List[Vector]]
    # [active_grain_index_in_tool_grains]
    current_active_grain_index_in_tool_nparray: np.ndarray

    def __init__(self, tool: Tool, workpiece: Workpiece, collider_config: CollisionDetectionConfig):
        # construct an initial collider result
        self.global_to_wp_frame_transform = Transform.get_frame_change_transform(
            [], up_chain=[workpiece.pose])
        self.workpiece_to_plane_transform = [Transform.get_frame_change_transform(
            [], [slice.pose]) for slice in workpiece.slices]

        self.collider_result = ColliderResult.from_all_false(
            len(tool.grains), len(workpiece.slices))
        # get proximities
        self.collider_result = self.update(
            tool, workpiece, collider_config)


    def get_grains_positions_in_two_frames(self, tool: Tool):
        """Get grain positions in global, workpiece, and plane frames and store it as attributes."""
        self.current_grains_positions_in_global_frame = tool.get_grain_positions_in_base_frame()
        self.current_grains_positions_in_wp_frame = [point.transform(self.global_to_wp_frame_transform)
                                                     for point in self.current_grains_positions_in_global_frame]

    def update(self, tool: Tool, wp: Workpiece, collider_config: CollisionDetectionConfig) -> ColliderResult:
        collider_result = ColliderResult.from_all_false(
            len(tool.grains), len(wp.slices))

        self.get_grains_positions_in_two_frames(tool)
        
        grains_to_wp_distance = collider_config.distance_function(
            self.current_grains_positions_in_wp_frame)

        # calculate the proximity result between every grain to workpiece, based on the collision detection threshold, which is usually max travelled distance of grain.
        collider_result.grains_in_workpiece_proximity = [
            True if distance <= collider_config.collision_detection_threshold else False for distance in grains_to_wp_distance]

        # calculate if grain is inside workpiece or not, based on maximal bounding sphere radius
        collider_result.grains_inside_workpiece = [False if result is False else (
            True if grains_to_wp_distance[index] <= collider_config.remove_material_threshold else False) for index, result in enumerate(collider_result.grains_in_workpiece_proximity)]

        # Get the index of active grains and non-active grains
        self.current_active_grain_index_in_tool_nparray: np.ndarray = np.where(
            collider_result.grains_in_workpiece_proximity)[0]
        non_active_grain_index_in_tool_nparray = np.where(
            np.logical_not(collider_result.grains_in_workpiece_proximity))[0]

        # Get the active grain positions in wp frame
        self.current_active_grains_positions_in_plane_frame = [[point.transform(
            wp_slice_transform) for point in np.asarray(self.current_grains_positions_in_wp_frame)[self.current_active_grain_index_in_tool_nparray].tolist()] for wp_slice_transform in self.workpiece_to_plane_transform]

        for plane_index, plane in enumerate(wp.slices):
            proximity_result = plane.points_proximities(
                self.current_active_grains_positions_in_plane_frame[plane_index],
                [grain.bounding_sphere_radius for grain in np.asarray(tool.grains)[self.current_active_grain_index_in_tool_nparray].tolist()])
            for index, active_grain_index in enumerate(self.current_active_grain_index_in_tool_nparray.tolist()):
                # check if grain crossed plane --> is_on_frontside has changed its value
                if self.collider_result.grains_on_frontside_of_planes[active_grain_index][plane_index] is not None:
                    if self.collider_result.grains_on_frontside_of_planes[active_grain_index][plane_index] != \
                            proximity_result[index].is_on_frontside:
                        collider_result.grains_crossed_planes[active_grain_index][plane_index] = True
                else:
                    collider_result.grains_crossed_planes[active_grain_index][plane_index] = False

                # fill in the rest of proximity result
                collider_result.grains_in_planes_proximity[active_grain_index][
                    plane_index] = proximity_result[index].is_in_proximity
                collider_result.grains_on_frontside_of_planes[active_grain_index][
                    plane_index] = proximity_result[index].is_on_frontside

        # Fill the collider result for non-active grains
        for non_active_grain_index in non_active_grain_index_in_tool_nparray.tolist():
            # Fill in the rest of proximity result
            collider_result.grains_in_planes_proximity[non_active_grain_index] = [
                None] * len(wp.slices)
            collider_result.grains_on_frontside_of_planes[non_active_grain_index] = [
                None] * len(wp.slices)
            collider_result.grains_crossed_planes[non_active_grain_index] = [
                None] * len(wp.slices)

        self.collider_result = collider_result

        return collider_result
