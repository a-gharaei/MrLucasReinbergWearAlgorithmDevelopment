'''This file contains the confiugration classes. Configuration classes provide the possibility of tuning options, settings and preferences of various modules.'''

from typing import List
from SimulationToolbox.PhysicalObjects import workpiece
from SimulationToolbox.Simulation.kinematics import Kinematics
from SimulationToolbox.PhysicalObjects.workpiece import Workpiece
from SimulationToolbox.PhysicalObjects.tool import Tool
from typing import Mapping, Callable
from SimulationToolbox.Geometry.geometry import Vector
from SimulationToolbox.Geometry.geometric_objects import VolumeProximityResult


class SimulationConfig:
    pass


class CollisionDetectionConfig:
    collision_detection_threshold: float
    remove_material_threshold: float
    distance_function: Callable[[List[Vector]], List[float]]

    def __init__(self, collision_detection_threshold: float, remove_material_threshold: float, distance_function: Callable[[List[Vector]], List[float]]):
        self.collision_detection_threshold = collision_detection_threshold
        self.remove_material_threshold = remove_material_threshold
        self.distance_function = distance_function

    @classmethod
    def for_all_tool_wp_contact_process(cls, tool: Tool, workpiece: Workpiece, kin: Kinematics):
        max_travelled_distance = kin.get_max_travelled_distance_of_grains(
            tool, kin.ToolTrajectory)
        max_grain_bounding_sphere_radius = tool.get_max_bounding_sphere_radius()
        distances_function = workpiece.distance_to_points
        return cls(max_travelled_distance, max_grain_bounding_sphere_radius, distances_function)

    @classmethod
    def for_partial_tool_wp_contact_process(cls, tool: Tool, workpiece: Workpiece, kin: Kinematics):
        max_travelled_distance = kin.get_max_travelled_distance_of_grains(
            tool, kin.ToolTrajectory)
        max_grain_bounding_sphere_radius = tool.get_max_bounding_sphere_radius()
        distance_function = workpiece.distance_to_points
        return cls(max_travelled_distance, max_grain_bounding_sphere_radius, distance_function)


class MaterialRemovalConfig:
    use_reduced_grain: bool
    check_approach_angle: bool
    apply_wear: bool
    collider_config: CollisionDetectionConfig

    def __init__(self, use_reduced_grain: bool, check_approach_angle: bool, apply_wear: bool, collider_config: CollisionDetectionConfig):
        self.check_approach_angle = check_approach_angle
        self.use_reduced_grain = use_reduced_grain
        self.apply_wear = apply_wear
        self.collider_config = collider_config

    # TODO: condense the use case of material removal into class methods. At the moment, there are just too many combinations of options to provide succinct class methods.
    #  milestone: 4


class PhysicalModelsConfig:
    pass


class KinematicsConfig:
    pass


class WearModelConfig:
    pass
