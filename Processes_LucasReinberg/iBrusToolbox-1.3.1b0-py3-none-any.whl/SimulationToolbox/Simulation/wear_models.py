import numpy as np
from SimulationToolbox.PhysicalObjects.tool import *
from SimulationToolbox.PhysicalObjects.grain import *
from SimulationToolbox.PhysicalObjects.workpiece import *
from SimulationToolbox.Geometry.geometry import *
from SimulationToolbox.Simulation import material_removal
from SimulationToolbox.Simulation.physical_models import *
from SimulationToolbox.Simulation.material_removal import *
from SimulationToolbox.Utilities.helpers import *


class AttritiousWearModelResult:
    wears_vector: List[Vector]
    wears_magnitude: List[float]

    def __init__(self, wears_vector: List[Vector], wears_magnitude: List[float]):
        self.wears_vector = wears_vector
        self.wears_magnitude = wears_magnitude


class AttritiousWearModelResultList:
    wears_vector_list: List[List[Vector]]
    wears_magnitude_list: List[List[float]]

    def __init__(self, wears_vector_list: List[List[Vector]], wears_magnitude_list: List[List[float]]):
        self.wears_vector_list = wears_vector_list
        self.wears_magnitude_list = wears_magnitude_list

    def save_to_disk(self, file_name: str):
        with open(file_name, 'wb') as file:
            dill.dump(self, file)

    @staticmethod
    def load_from_disk(file_name):
        with open(file_name, 'rb') as file:
            wear_model_results = dill.load(file)
        if isinstance(wear_model_results, AttritiousWearModelResultList):
            return wear_model_results
        else:
            Exception(
                "The loaded AttritiousWearModelResultList object is not from the current version of this class.")


class BondingWearModelResult:
    wears_vector: List[Vector]
    wears_magnitude: List[float]

    def __init__(self, wears_vector: List[Vector], wears_magnitude: List[float]):
        self.wears_vector = wears_vector
        self.wears_magnitude = wears_magnitude


def apply_bonding_wear(wear_model_result: BondingWearModelResult, tool: Tool):
    if len(tool.grains) != len(wear_model_result.wears_vector):
        raise Exception('Wear model results does not match number of grains!')

    for grain_idx, grain in enumerate(tool.grains):
        grain.center_protrusion.add(wear_model_result.wears_vector[grain_idx])


def modify_reduced_grains(tool: Tool, mat_removal_result):

    for idx, grain in enumerate(tool.grains):
        if mat_removal_result.penetration_depths[idx] != 0:
            grain_displacement_in_grain_frame = grain.reduced_grain.displacement_in_grain_frame

            # project_mesh_along_velocity
            projected_mesh = grain.get_mesh().transform(
                Transform.from_projection_along_vector_to_x_z_plane(grain_displacement_in_grain_frame))
            projected_fm = projected_mesh.to_flatmanifold(
                default_precision)
            mesh_indices_for_fm_points = []
            for point in projected_fm.area.get_boundary_points():
                for vertex_idx, vertex in enumerate(projected_mesh.vertices):
                    if point.x() == vertex.x() and point.z() == vertex.z():
                        mesh_indices_for_fm_points.append(vertex_idx)
                        break
            grain.reduced_grain.set_mesh_indices_corresponds_to_projected_fm_points(
                mesh_indices_for_fm_points)
            grain.reduced_grain.projected_area = projected_fm
            grain.reduced_grain.projected_mesh_ancestor = projected_mesh


def apply_attritious_wear(wear_model_result: AttritiousWearModelResult, tool: Tool, mat_remover_result: 'MaterialRemovalResult', use_reduced_grain):

    if len(tool.grains) != len(wear_model_result.wears_vector):
        raise Exception('Wear model results does not match number of grains!')

    for grain_idx, grain in enumerate(tool.grains):
        if mat_remover_result.leading_vertex_indices[grain_idx] != -1:
            grain.get_mesh().vertices[mat_remover_result.leading_vertex_indices[grain_idx]] = \
                grain.get_mesh().vertices[mat_remover_result.leading_vertex_indices[grain_idx]].add(
                wear_model_result.wears_vector[grain_idx])
            if (grain.get_mesh().vertices[mat_remover_result.leading_vertex_indices[grain_idx]].norm() - grain.bounding_sphere_radius) > default_precision:
                grain.get_mesh().vertices[mat_remover_result.leading_vertex_indices[grain_idx]] = \
                    grain.get_mesh().vertices[mat_remover_result.leading_vertex_indices[grain_idx]].normalize(
                ).scale(grain.bounding_sphere_radius)

    if use_reduced_grain:
        modify_reduced_grains(tool, mat_remover_result)


# Pullout criteria


def apply_pullout_condition(tool: Tool, grain_force_model_result: 'GrainForceModelResult', mat_remover_result,
                            bonding_strength: float = 0, retention_force: float = 0):
    "For the pullout condition, set only one of following: Bonding strength or retention force."
    # TODO: Capability to take a set of retention force values and use them accordingly for changing bonding height

    for grain_idx, grain in enumerate(tool.grains):
        if mat_remover_result.removed_volumes[grain_idx] > default_precision:
            cutting_force = grain_force_model_result.grain_forces[grain_idx].cutting_force

            leading_edge_vertex = grain.get_mesh(
            ).vertices[mat_remover_result.leading_vertex_indices[grain_idx]]
            surface_normal_in_grain_frame = tool.cutting_surface_normal.change_frame_vector([
            ], [grain.pose])
            edge_distance_to_center = abs(leading_edge_vertex.dot(
                surface_normal_in_grain_frame.normalize())/surface_normal_in_grain_frame.norm())
            center_protrusion_magnitude = grain.center_protrusion.dot(
                tool.cutting_surface_normal)
            bonding_height = grain.bounding_sphere_radius - center_protrusion_magnitude

            # Limit force/strength to resist pullout
            # Equation below is taken from this dissertation: https://doi.org/10.3929/ethz-b-000426867
            # Page 130
            retention_force_required = cutting_force.norm() * \
                (6*(edge_distance_to_center + center_protrusion_magnitude) +
                 3*bonding_height)/(4*bonding_height)

            if bonding_strength > 0 and retention_force == 0:
                grain_bonding_area = 2*np.pi*grain.bounding_sphere_radius*bonding_height
                bonding_strength_required = retention_force_required/grain_bonding_area
                if bonding_strength < bonding_strength_required:
                    grain.pullout = True
            elif bonding_strength == 0 and retention_force > 0:
                if retention_force < retention_force_required:
                    grain.pullout = True
            else:
                raise Exception("None or both bonding_strength and retention_force are set above zero.  \
                    Please only use either bonding_strength or retention_force. ")

# Functions for calculation of intermediary variables for wear


def calculate_penetration_depth_list(plane: FlatManifold, penetrated_plane_boundary: pygeos.geometry,
                                     projected_area_boundary: List[Vector]) -> List[float]:
    # calculate max penetration depth
    penetration_depths = [0]*len(projected_area_boundary)
    point_list = []
    for point in projected_area_boundary:
        point_list.append(pygeos.points(
            [point.x(), point.z()]))
    tree = pygeos.STRtree(point_list)
    penetrating_points = tree.query(
        plane.area.area, predicate='contains').tolist()
    for i in penetrating_points:
        penetration_depths[i] = pygeos.distance(
            penetrated_plane_boundary, point_list[i])

    if len(penetration_depths) == 0:
        raise Exception(
            'No grain penetration is detected')

    return penetration_depths


def calculate_leading_vertex_index(penetration_depths: List[float], mesh_indices: List[int]) -> int:

    if len(mesh_indices) < len(penetration_depths):
        raise Exception(
            "The length of mesh indicies is smaller than penetration depth list.")

    leading_vertex_index = mesh_indices[int(
        np.argmax(penetration_depths))]

    return leading_vertex_index


def calculate_wear_direction(wp: Workpiece, tool: Tool, grain_crossed_one_plane: 'OneGrainCrossOnePlaneInfoCollector') -> Vector:
    '''This function calculates the 3D vector along which grain leading vertex will be moved for wear. TheThe magnitude of this direction vector
    can be utilized as penetration depth corrected for 3D'''

    # get the leading vertex point

    le_point = grain_crossed_one_plane.penetration_calculation.projected_area_boundary[grain_crossed_one_plane.wear_calculation_prior.mesh_indices_pointer_to_projected_area.index(
        grain_crossed_one_plane.wear_calculation_prior.leading_vertex_index)]
    le_in_plane_frame = pygeos.points([le_point.x(), le_point.z()])

    le_coords = pygeos.get_coordinates(
        le_in_plane_frame).tolist()
    line_from_le_to_boundary = pygeos.get_coordinates(
        pygeos.shortest_line(grain_crossed_one_plane.penetration_calculation.penetrated_plane_boundary, le_in_plane_frame)).tolist()

    # calculate wear direction as normal to grinded surface, towards grain
    wear_direction_in_wp_frame = Vector(
        line_from_le_to_boundary[0][0] - le_coords[0][0], 0, line_from_le_to_boundary[0][1] - le_coords[0][1]).change_frame_vector([wp.slices[grain_crossed_one_plane.plane_index].pose], [])

    # new frame to project wear direction onto grain position
    # TODO:
    grain_position = tool.grains[grain_crossed_one_plane.grain_index].get_position(
    )
    if grain_position.norm() == 0:
        grain_position = grain_crossed_one_plane.grain_displacement_in_plane.change_frame_vector(
            [wp.slices[grain_crossed_one_plane.plane_index].pose, wp.pose], [tool.pose]).cross(Vector.e_z())
    angle_for_transform = np.arccos(grain_position.dot(
        Vector.e_x())/(grain_position.norm() * Vector.e_x().norm()))
    if Vector.e_x().cross(grain_position).z() < 0:
        angle_for_transform = - angle_for_transform
    new_frame_pose = Pose(Transform.from_axis_angle(
        Vector.e_z(), angle_for_transform))

    wear_direction_in_new_frame = wear_direction_in_wp_frame.change_frame_vector(
        [wp.pose], [tool.pose, new_frame_pose])

    projected_wear_direction = Vector(
        wear_direction_in_new_frame.x(), 0, wear_direction_in_new_frame.z())
    projected_wear_direction_in_grain_frame = projected_wear_direction.change_frame_vector([new_frame_pose],
                                                                                           [tool.grains[grain_crossed_one_plane.grain_index].pose])

    return projected_wear_direction_in_grain_frame
