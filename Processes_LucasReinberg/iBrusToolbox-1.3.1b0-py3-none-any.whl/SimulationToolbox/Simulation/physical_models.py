from SimulationToolbox.PhysicalObjects.tool import *
from SimulationToolbox.PhysicalObjects.grain import *
from SimulationToolbox.Geometry.geometry import *
from SimulationToolbox.Simulation.material_removal import *
from SimulationToolbox.Utilities.helpers import compare_np_arrays
import pandas as pd


class GrainForce:
    # represented in the grain frame
    total_force: Vector
    cutting_force: Vector
    normal_force: Vector

    def __init__(self, total_force: Vector, cutting_force: Vector, normal_force: Vector):
        self.total_force = total_force
        self.cutting_force = cutting_force
        self.normal_force = normal_force


# TODO: add functionality to output the results in the excel file.


class GrainForceModelResult:
    # in which frame are the forces represented --> in grain Frame
    grain_forces: List[GrainForce]

    def __init__(self, grain_forces: List[GrainForce]):
        self.grain_forces = grain_forces

    @classmethod
    def from_all_none(cls, tool: Tool):
        grain_forces = [None] * len(tool.grains)
        return cls(grain_forces)

    def compare(self, other, precision: float):
        if isinstance(other, GrainForceModelResult):
            for grain_id, grain_force in enumerate(self.grain_forces):
                if grain_force is not None:
                    grain_force.total_force.compare(
                        other.grain_forces[grain_id].total_force, precision)
                    grain_force.cutting_force.compare(
                        other.grain_forces[grain_id].cutting_force, precision)
                    grain_force.normal_force.compare(
                        other.grain_forces[grain_id].normal_force, precision)
                else:
                    # if the both results are None, it should point to the same None object and pass the comparison
                    grain_force == other.grain_forces[grain_id]

        else:
            raise InputAreNotTheSameDataType


class GrainForceModelResultListNumpyArrays:
    """Transfer the Grain force model result into format of lists of numpy arrays. One numpy array per grain."""
    # for each element in the list we have the force values over time for a grain
    grain_forces_x: List[np.ndarray]
    grain_forces_y: List[np.ndarray]
    grain_forces_z: List[np.ndarray]

    def __init__(self,
                 grain_forces_x: List[np.ndarray],
                 grain_forces_y: List[np.ndarray],
                 grain_forces_z: List[np.ndarray]):
        self.grain_forces_x = grain_forces_x
        self.grain_forces_y = grain_forces_y
        self.grain_forces_z = grain_forces_z

    @ classmethod
    def from_grain_force_model_result_list(cls, result_list: List[GrainForceModelResult]):
        number_of_grains = len(result_list[0].grain_forces)
        number_of_timestep = len(result_list)
        size = (number_of_grains, number_of_timestep)
        grain_forces_x: np.ndarray = np.zeros(size)
        grain_forces_y: np.ndarray = np.zeros(size)
        grain_forces_z: np.ndarray = np.zeros(size)
        # loop over timesteps
        for time_index, result in enumerate(result_list):
            # loop over grains
            for grin_idx, grain_force in enumerate(result.grain_forces):
                if grain_force is not None:
                    grain_forces_x[grin_idx][time_index] = grain_force.total_force.x(
                    )
                    grain_forces_y[grin_idx][time_index] = grain_force.total_force.y(
                    )
                    grain_forces_z[grin_idx][time_index] = grain_force.total_force.z(
                    )
                else:
                    grain_forces_x[grin_idx][time_index] = None
                    grain_forces_y[grin_idx][time_index] = None
                    grain_forces_z[grin_idx][time_index] = None
        return cls(grain_forces_x, grain_forces_y, grain_forces_z)

    def compare(self, other, precision):
        if isinstance(other, GrainForceModelResultListNumpyArrays):
            for index in range(0, len(self.grain_forces_x)):
                compare_np_arrays(
                    self.grain_forces_x[index], other.grain_forces_x[index], precision)
                compare_np_arrays(
                    self.grain_forces_y[index], other.grain_forces_y[index], precision)
                compare_np_arrays(
                    self.grain_forces_z[index], other.grain_forces_z[index], precision)
        else:
            raise InputAreNotTheSameDataType

    def save_to_disk(self, file_name: str):
        with open(file_name, 'wb') as file:
            dill.dump(self, file)

    @staticmethod
    def load_from_disk(file_name):
        with open(file_name, 'rb') as file:
            grain_force_model_result_np = dill.load(file)
        if isinstance(grain_force_model_result_np, GrainForceModelResultListNumpyArrays):
            return grain_force_model_result_np
        else:
            Exception(
                "The loaded GrainForceModelResultListNumpyArrays object is not from the current version of this class.")


class ToolForceModelResult:
    # represented in the tool frame
    torque_around_rotation_axis: float
    force: Vector

    def __init__(self, torque_around_rotation_axis: float, force: Vector):
        self.torque_around_rotation_axis = torque_around_rotation_axis
        self.force = force

    def compare(self, other, precision: float):
        if isinstance(other, ToolForceModelResult):
            self.force.compare(other.force, precision)
            assert (np.abs(self.torque_around_rotation_axis -
                           other.torque_around_rotation_axis) <= precision)
        else:
            raise InputAreNotTheSameDataType


class ToolForceModelResultListFloat:
    """Transfer the Tool force model result into format of lists of float numbers."""
    tool_forces_x: List[float]
    tool_forces_y: List[float]
    tool_forces_z: List[float]
    torques_around_rotation_axis: List[float]

    def __init__(self,
                 tool_forces_x: List[float],
                 tool_forces_y: List[float],
                 tool_forces_z: List[float],
                 torques_around_rotation_axis: List[float]):
        self.tool_forces_x = tool_forces_x
        self.tool_forces_y = tool_forces_y
        self.tool_forces_z = tool_forces_z
        self.torques_around_rotation_axis = torques_around_rotation_axis

    @ classmethod
    def from_tool_force_model_result_list(cls, result_list: List[ToolForceModelResult]):
        tool_forces_x: List[float] = []
        tool_forces_y: List[float] = []
        tool_forces_z: List[float] = []
        torques_around_rotation_axis: List[float] = []
        # loop over timesteps
        for result in result_list:
            tool_forces_x.append(result.force.x())
            tool_forces_y.append(result.force.y())
            tool_forces_z.append(result.force.z())
            torques_around_rotation_axis.append(
                result.torque_around_rotation_axis)

        return cls(tool_forces_x, tool_forces_y, tool_forces_z, torques_around_rotation_axis)

    def get_in_dataframe(self):
        return pd.DataFrame.from_dict({'tool force X': self.tool_forces_x,
                                       'tool force Y': self.tool_forces_y,
                                       'tool force Z': self.tool_forces_z})

    def compare(self, other, precision):
        if isinstance(other, ToolForceModelResultListFloat):
            for index in range(0, len(self.tool_forces_x)):
                cond_x = np.abs(
                    self.tool_forces_x[index] - other.tool_forces_x[index]) <= precision
                cond_y = np.abs(
                    self.tool_forces_y[index] - other.tool_forces_y[index]) <= precision
                cond_z = np.abs(
                    self.tool_forces_z[index] - other.tool_forces_z[index]) <= precision
                if cond_x == True & cond_y == True & cond_z == True:
                    continue
                else:
                    raise Exception(
                        "These two list are not equal with in precision.")
        else:
            raise InputAreNotTheSameDataType

    # TODO: Add tests for get_forces_in_global and get_global_forces_in_new_frame functions
    def get_forces_in_global(self, tool_trajectory: PoseTrajectory):
        forces_x_vector = []
        forces_y_vector = []
        forces_z_vector = []
        time_idx = 0

        if not len(self.tool_forces_x) == len(tool_trajectory.poses):
            raise Exception(
                'Force result list and trajectory do not have same size')

        # change frame of forces from tool-pose to global
        for pose in tool_trajectory.poses:
            tool_force = Vector(self.tool_forces_x[time_idx],
                                self.tool_forces_y[time_idx],
                                self.tool_forces_z[time_idx])
            tool_force = tool_force.change_frame_vector([pose], [])

            forces_x_vector.append(tool_force.x())
            forces_y_vector.append(tool_force.y())
            forces_z_vector.append(tool_force.z())
            time_idx += 1

        return ToolForceModelResultListFloat(np.asarray(forces_x_vector),
                                             np.asarray(forces_y_vector),
                                             np.asarray(forces_z_vector),
                                             self.torques_around_rotation_axis)

    def get_global_forces_in_new_frame(self, new_frame_pose: Pose):
        """This function takes forces represented in global frame and the pose of new frame with respect to global frame as inputs"""
        forces_x_vector = []
        forces_y_vector = []
        forces_z_vector = []

        # change frame of forces from global to pose of new frame
        for idx in range(len(self.tool_forces_x)):
            tool_force = Vector(self.tool_forces_x[idx],
                                self.tool_forces_y[idx],
                                self.tool_forces_z[idx])
            tool_force = tool_force.change_frame_vector([], [new_frame_pose])

            forces_x_vector.append(tool_force.x())
            forces_y_vector.append(tool_force.y())
            forces_z_vector.append(tool_force.z())

        return ToolForceModelResultListFloat(np.asarray(forces_x_vector),
                                             np.asarray(forces_y_vector),
                                             np.asarray(forces_z_vector),
                                             self.torques_around_rotation_axis)

    def save_to_disk(self, file_name: str):
        with open(file_name, 'wb') as file:
            dill.dump(self, file)

    @staticmethod
    def load_from_disk(file_name):
        with open(file_name, 'rb') as file:
            tool_force_model_result_lf = dill.load(file)
        if isinstance(tool_force_model_result_lf, ToolForceModelResultListFloat):
            return tool_force_model_result_lf
        else:
            Exception(
                "The loaded ToolForceModelResultListFloat object is not from the current version of this class.")


def tool_force_model(grain_force_model_result: GrainForceModelResult,
                     tool: Tool) -> ToolForceModelResult:
    'The force results of this function are represented in tool frame'

    tool_force = Vector.origin()
    torque_around_rotation_axis = 0

    active_grain_index = [index for index,
                          grain_force in enumerate(grain_force_model_result.grain_forces) if grain_force is not None]

    # aggregate Forces & torques
    for grain_id in active_grain_index:
        # calculate forces represented in tool frame
        grain_force_in_tool_frame = grain_force_model_result.grain_forces[grain_id].\
            total_force

        normalized_rotation_axis = tool.rotation_axis
        rotation_center_of_grain = normalized_rotation_axis.scale(
            normalized_rotation_axis.dot(tool.grains[grain_id].get_position()))
        radius_vector = tool.grains[grain_id].get_position().subtract(
            rotation_center_of_grain)

        tool_force = tool_force.add(grain_force_in_tool_frame)

        torque_vector = radius_vector.cross(grain_force_in_tool_frame)
        torque_around_rotation_axis += -(torque_vector.dot(
            tool.rotation_axis))

    return ToolForceModelResult(torque_around_rotation_axis, tool_force)

# methods to get force reuslts in desired time step ranges
# TODO: Determine if to carry force result range slicing methods into processes or not


def get_all_force_results_at_range_in_array(grain_force_results: List[GrainForceModelResult], tool_force_results: List[ToolForceModelResult],
                                            tool_trajectory: PoseTrajectory, slice_range: List[int] = [0, None, 1]):

    if slice_range[1] is None:
        slice_range[1] == len(tool_trajectory.poses)

    grain_forces_array = GrainForceModelResultListNumpyArrays.from_grain_force_model_result_list(
        grain_force_results[slice_range[0]:slice_range[1]:slice_range[2]])
    tool_forces_array = ToolForceModelResultListFloat.from_tool_force_model_result_list(
        tool_force_results[slice_range[0]:slice_range[1]:slice_range[2]])
    global_forces_array = tool_forces_array.get_forces_in_global(
        tool_trajectory.slice(slice_range[0], slice_range[1], slice_range[2]))

    return grain_forces_array, tool_forces_array, global_forces_array


def get_grain_force_results_in_time_step_range(grain_force_results: GrainForceModelResultListNumpyArrays, slice_range: List[int] = [0, None, 1]):

    sliced_grain_forces_x = [grain_forces[slice_range[0]:slice_range[1]:slice_range[2]]
                             for grain_forces in grain_force_results.grain_forces_x]
    sliced_grain_forces_y = [grain_forces[slice_range[0]:slice_range[1]:slice_range[2]]
                             for grain_forces in grain_force_results.grain_forces_y]
    sliced_grain_forces_z = [grain_forces[slice_range[0]:slice_range[1]:slice_range[2]]
                             for grain_forces in grain_force_results.grain_forces_z]

    return GrainForceModelResultListNumpyArrays(sliced_grain_forces_x, sliced_grain_forces_y, sliced_grain_forces_z)


def get_tool_force_results_in_time_step_range(tool_force_results: ToolForceModelResultListFloat, slice_range: List[int] = [0, None, 1]):
    "Input can be tool force model results in tool or golbal frame."

    sliced_tool_forces_x = tool_force_results.tool_forces_x[slice_range[0]
        :slice_range[1]:slice_range[2]]
    sliced_tool_forces_y = tool_force_results.tool_forces_y[slice_range[0]
        :slice_range[1]:slice_range[2]]
    sliced_tool_forces_z = tool_force_results.tool_forces_z[slice_range[0]
        :slice_range[1]:slice_range[2]]
    sliced_torques_around_rotation_axis = tool_force_results.torques_around_rotation_axis[
        slice_range[0]:slice_range[1]:slice_range[2]]

    return ToolForceModelResultListFloat(sliced_tool_forces_x, sliced_tool_forces_y, sliced_tool_forces_z, sliced_torques_around_rotation_axis)


# Testing if mentioning people to review code in Github Desktop is working or not.
